namespace InterfazDeskTop
{
    partial class UcVentas
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.lbl_titulo = new System.Windows.Forms.Label();
            // ── Panel izquierdo: búsqueda ─────────────────────────────────────
            this.panel_busqueda = new System.Windows.Forms.Panel();
            this.lbl_busqueda_titulo = new System.Windows.Forms.Label();
            this.txb_busqueda = new System.Windows.Forms.TextBox();
            this.lv_productos = new System.Windows.Forms.ListView();
            this.col_prod_nombre = new System.Windows.Forms.ColumnHeader();
            this.col_prod_precio = new System.Windows.Forms.ColumnHeader();
            this.col_prod_stock = new System.Windows.Forms.ColumnHeader();
            this.btn_agregar = new System.Windows.Forms.Button();
            // ── Panel derecho: carrito + cobro ────────────────────────────────
            this.panel_carrito = new System.Windows.Forms.Panel();
            this.lbl_carrito_titulo = new System.Windows.Forms.Label();
            this.dgv_carrito = new System.Windows.Forms.DataGridView();
            this.col_c_nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_c_cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_c_precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_c_subtotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_quitar = new System.Windows.Forms.Button();
            this.btn_limpiar = new System.Windows.Forms.Button();
            // ── Panel cobro ───────────────────────────────────────────────────
            this.panel_cobro = new System.Windows.Forms.Panel();
            this.lbl_subtotal_lbl = new System.Windows.Forms.Label();
            this.lbl_val_subtotal = new System.Windows.Forms.Label();
            this.lbl_total_lbl = new System.Windows.Forms.Label();
            this.lbl_val_total = new System.Windows.Forms.Label();
            this.lbl_monto_lbl = new System.Windows.Forms.Label();
            this.txb_monto_recibido = new System.Windows.Forms.TextBox();
            this.lbl_cambio_lbl = new System.Windows.Forms.Label();
            this.lbl_val_cambio = new System.Windows.Forms.Label();
            this.lbl_metodo_lbl = new System.Windows.Forms.Label();
            this.cmb_metodo_pago = new System.Windows.Forms.ComboBox();
            this.btn_pagar = new System.Windows.Forms.Button();

            this.panel_busqueda.SuspendLayout();
            this.panel_carrito.SuspendLayout();
            this.panel_cobro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_carrito)).BeginInit();
            this.SuspendLayout();

            // ── lbl_titulo ────────────────────────────────────────────────────
            this.lbl_titulo.AutoSize = false;
            this.lbl_titulo.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_titulo.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.lbl_titulo.Location = new System.Drawing.Point(30, 20);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(300, 45);
            this.lbl_titulo.Text = "Nueva Venta";

            // ══ PANEL IZQUIERDO: BÚSQUEDA ════════════════════════════════════
            this.panel_busqueda.BackColor = System.Drawing.Color.White;
            this.panel_busqueda.Location = new System.Drawing.Point(30, 75);
            this.panel_busqueda.Name = "panel_busqueda";
            this.panel_busqueda.Size = new System.Drawing.Size(440, 530);
            this.panel_busqueda.TabIndex = 1;
            this.panel_busqueda.Anchor = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Bottom
                | System.Windows.Forms.AnchorStyles.Left;
            this.panel_busqueda.Controls.Add(this.lbl_busqueda_titulo);
            this.panel_busqueda.Controls.Add(this.txb_busqueda);
            this.panel_busqueda.Controls.Add(this.lv_productos);
            this.panel_busqueda.Controls.Add(this.btn_agregar);

            this.lbl_busqueda_titulo.AutoSize = false;
            this.lbl_busqueda_titulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_busqueda_titulo.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.lbl_busqueda_titulo.Location = new System.Drawing.Point(15, 15);
            this.lbl_busqueda_titulo.Size = new System.Drawing.Size(200, 28);
            this.lbl_busqueda_titulo.Text = "Buscar Producto";

            this.txb_busqueda.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txb_busqueda.Location = new System.Drawing.Point(15, 50);
            this.txb_busqueda.Name = "txb_busqueda";
            // PlaceholderText no está disponible en .NET Framework 4.x
            // El texto de ayuda se muestra como Text inicial y se limpia al hacer foco
            this.txb_busqueda.Text = "Buscar por nombre o código de barras...";
            this.txb_busqueda.ForeColor = System.Drawing.Color.Gray;
            this.txb_busqueda.GotFocus += (s, e) => {
                if (this.txb_busqueda.Text == "Buscar por nombre o código de barras...") {
                    this.txb_busqueda.Text = "";
                    this.txb_busqueda.ForeColor = System.Drawing.Color.Black;
                }
            };
            this.txb_busqueda.LostFocus += (s, e) => {
                if (string.IsNullOrWhiteSpace(this.txb_busqueda.Text)) {
                    this.txb_busqueda.Text = "Buscar por nombre o código de barras...";
                    this.txb_busqueda.ForeColor = System.Drawing.Color.Gray;
                }
            };
            this.txb_busqueda.Size = new System.Drawing.Size(410, 28);
            this.txb_busqueda.TabIndex = 0;
            this.txb_busqueda.TextChanged += new System.EventHandler(this.txb_busqueda_TextChanged);

            this.lv_productos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                this.col_prod_nombre, this.col_prod_precio, this.col_prod_stock });
            this.lv_productos.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lv_productos.FullRowSelect = true;
            this.lv_productos.GridLines = true;
            this.lv_productos.HideSelection = false;
            this.lv_productos.Location = new System.Drawing.Point(15, 88);
            this.lv_productos.MultiSelect = false;
            this.lv_productos.Name = "lv_productos";
            this.lv_productos.Size = new System.Drawing.Size(410, 390);
            this.lv_productos.TabIndex = 1;
            this.lv_productos.UseCompatibleStateImageBehavior = false;
            this.lv_productos.View = System.Windows.Forms.View.Details;
            this.lv_productos.DoubleClick += new System.EventHandler(this.lv_productos_DoubleClick);

            this.col_prod_nombre.Text = "Nombre";
            this.col_prod_nombre.Width = 220;
            this.col_prod_precio.Text = "Precio";
            this.col_prod_precio.Width = 90;
            this.col_prod_stock.Text = "Stock";
            this.col_prod_stock.Width = 80;

            this.btn_agregar.BackColor = System.Drawing.Color.FromArgb(249, 115, 22);
            this.btn_agregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_agregar.FlatAppearance.BorderSize = 0;
            this.btn_agregar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btn_agregar.ForeColor = System.Drawing.Color.White;
            this.btn_agregar.Location = new System.Drawing.Point(15, 488);
            this.btn_agregar.Name = "btn_agregar";
            this.btn_agregar.Size = new System.Drawing.Size(410, 34);
            this.btn_agregar.Text = "+ Agregar al carrito";
            this.btn_agregar.TabIndex = 2;
            this.btn_agregar.Click += new System.EventHandler(this.btn_agregar_Click);

            // ══ PANEL DERECHO: CARRITO ════════════════════════════════════════
            this.panel_carrito.BackColor = System.Drawing.Color.White;
            this.panel_carrito.Location = new System.Drawing.Point(490, 75);
            this.panel_carrito.Name = "panel_carrito";
            this.panel_carrito.Size = new System.Drawing.Size(470, 325);
            this.panel_carrito.TabIndex = 2;
            this.panel_carrito.Anchor = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Right;
            this.panel_carrito.Controls.Add(this.lbl_carrito_titulo);
            this.panel_carrito.Controls.Add(this.dgv_carrito);
            this.panel_carrito.Controls.Add(this.btn_quitar);
            this.panel_carrito.Controls.Add(this.btn_limpiar);

            this.lbl_carrito_titulo.AutoSize = false;
            this.lbl_carrito_titulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_carrito_titulo.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.lbl_carrito_titulo.Location = new System.Drawing.Point(15, 15);
            this.lbl_carrito_titulo.Size = new System.Drawing.Size(200, 28);
            this.lbl_carrito_titulo.Text = "Carrito de Compras";

            this.dgv_carrito.AllowUserToAddRows = false;
            this.dgv_carrito.AllowUserToDeleteRows = false;
            this.dgv_carrito.AllowUserToResizeRows = false;
            this.dgv_carrito.BackgroundColor = System.Drawing.Color.White;
            this.dgv_carrito.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_carrito.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.dgv_carrito.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgv_carrito.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgv_carrito.ColumnHeadersHeight = 34;
            this.dgv_carrito.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_carrito.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dgv_carrito.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(253, 186, 116);
            this.dgv_carrito.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgv_carrito.EnableHeadersVisualStyles = false;
            this.dgv_carrito.GridColor = System.Drawing.Color.FromArgb(230, 230, 230);
            this.dgv_carrito.Location = new System.Drawing.Point(15, 50);
            this.dgv_carrito.Name = "dgv_carrito";
            this.dgv_carrito.ReadOnly = true;
            this.dgv_carrito.RowHeadersVisible = false;
            this.dgv_carrito.RowTemplate.Height = 32;
            this.dgv_carrito.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_carrito.Size = new System.Drawing.Size(440, 220);
            this.dgv_carrito.TabIndex = 0;
            this.dgv_carrito.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.col_c_nombre, this.col_c_cantidad, this.col_c_precio, this.col_c_subtotal });

            this.col_c_nombre.HeaderText = "Producto";
            this.col_c_nombre.Name = "col_c_nombre";
            this.col_c_nombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col_c_cantidad.HeaderText = "Cant.";
            this.col_c_cantidad.Name = "col_c_cantidad";
            this.col_c_cantidad.Width = 55;
            this.col_c_precio.HeaderText = "Precio";
            this.col_c_precio.Name = "col_c_precio";
            this.col_c_precio.Width = 85;
            this.col_c_subtotal.HeaderText = "Subtotal";
            this.col_c_subtotal.Name = "col_c_subtotal";
            this.col_c_subtotal.Width = 90;

            this.btn_quitar.BackColor = System.Drawing.Color.FromArgb(239, 68, 68);
            this.btn_quitar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_quitar.FlatAppearance.BorderSize = 0;
            this.btn_quitar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_quitar.ForeColor = System.Drawing.Color.White;
            this.btn_quitar.Location = new System.Drawing.Point(15, 280);
            this.btn_quitar.Name = "btn_quitar";
            this.btn_quitar.Size = new System.Drawing.Size(210, 32);
            this.btn_quitar.Text = "Quitar seleccionado";
            this.btn_quitar.TabIndex = 1;
            this.btn_quitar.Click += new System.EventHandler(this.btn_quitar_Click);

            this.btn_limpiar.BackColor = System.Drawing.Color.FromArgb(127, 140, 141);
            this.btn_limpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_limpiar.FlatAppearance.BorderSize = 0;
            this.btn_limpiar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_limpiar.ForeColor = System.Drawing.Color.White;
            this.btn_limpiar.Location = new System.Drawing.Point(245, 280);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(210, 32);
            this.btn_limpiar.Text = "Limpiar carrito";
            this.btn_limpiar.TabIndex = 2;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);

            // ══ PANEL COBRO ═══════════════════════════════════════════════════
            this.panel_cobro.BackColor = System.Drawing.Color.White;
            this.panel_cobro.Location = new System.Drawing.Point(490, 415);
            this.panel_cobro.Name = "panel_cobro";
            this.panel_cobro.Size = new System.Drawing.Size(470, 190);
            this.panel_cobro.TabIndex = 3;
            this.panel_cobro.Anchor = System.Windows.Forms.AnchorStyles.Bottom
                | System.Windows.Forms.AnchorStyles.Right;
            this.panel_cobro.Controls.Add(this.lbl_subtotal_lbl);
            this.panel_cobro.Controls.Add(this.lbl_val_subtotal);
            this.panel_cobro.Controls.Add(this.lbl_total_lbl);
            this.panel_cobro.Controls.Add(this.lbl_val_total);
            this.panel_cobro.Controls.Add(this.lbl_monto_lbl);
            this.panel_cobro.Controls.Add(this.txb_monto_recibido);
            this.panel_cobro.Controls.Add(this.lbl_cambio_lbl);
            this.panel_cobro.Controls.Add(this.lbl_val_cambio);
            this.panel_cobro.Controls.Add(this.lbl_metodo_lbl);
            this.panel_cobro.Controls.Add(this.cmb_metodo_pago);
            this.panel_cobro.Controls.Add(this.btn_pagar);

            // Subtotal
            SetLabelPair(this.lbl_subtotal_lbl, this.lbl_val_subtotal, 15, 15, "Subtotal:", "$0.00");
            // Total
            this.lbl_total_lbl.AutoSize = false;
            this.lbl_total_lbl.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_total_lbl.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.lbl_total_lbl.Location = new System.Drawing.Point(15, 42);
            this.lbl_total_lbl.Size = new System.Drawing.Size(80, 24);
            this.lbl_total_lbl.Text = "Total:";
            this.lbl_val_total.AutoSize = false;
            this.lbl_val_total.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lbl_val_total.ForeColor = System.Drawing.Color.FromArgb(34, 197, 94);
            this.lbl_val_total.Location = new System.Drawing.Point(200, 38);
            this.lbl_val_total.Size = new System.Drawing.Size(120, 28);
            this.lbl_val_total.Text = "$0.00";
            this.lbl_val_total.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // Monto recibido
            SetLabelPair(this.lbl_monto_lbl, null, 15, 76, "Monto recibido:", null);
            this.txb_monto_recibido.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txb_monto_recibido.Location = new System.Drawing.Point(200, 73);
            this.txb_monto_recibido.Name = "txb_monto_recibido";
            this.txb_monto_recibido.Size = new System.Drawing.Size(120, 26);
            this.txb_monto_recibido.Text = "0";
            this.txb_monto_recibido.TabIndex = 0;
            this.txb_monto_recibido.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txb_monto_recibido.TextChanged += new System.EventHandler(this.txb_monto_recibido_TextChanged);
            // Cambio
            SetLabelPair(this.lbl_cambio_lbl, this.lbl_val_cambio, 15, 108, "Cambio:", "$0.00");
            this.lbl_val_cambio.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_val_cambio.ForeColor = System.Drawing.Color.FromArgb(34, 197, 94);
            // Método de pago
            this.lbl_metodo_lbl.AutoSize = false;
            this.lbl_metodo_lbl.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lbl_metodo_lbl.ForeColor = System.Drawing.Color.FromArgb(80, 80, 80);
            this.lbl_metodo_lbl.Location = new System.Drawing.Point(15, 140);
            this.lbl_metodo_lbl.Size = new System.Drawing.Size(120, 22);
            this.lbl_metodo_lbl.Text = "Método de pago:";
            this.cmb_metodo_pago.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_metodo_pago.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmb_metodo_pago.Items.AddRange(new object[] { "Efectivo", "Tarjeta", "Transferencia" });
            this.cmb_metodo_pago.Location = new System.Drawing.Point(200, 137);
            this.cmb_metodo_pago.Name = "cmb_metodo_pago";
            this.cmb_metodo_pago.SelectedIndex = 0;
            this.cmb_metodo_pago.Size = new System.Drawing.Size(120, 26);
            this.cmb_metodo_pago.TabIndex = 1;

            // Botón pagar
            this.btn_pagar.BackColor = System.Drawing.Color.FromArgb(249, 115, 22);
            this.btn_pagar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pagar.FlatAppearance.BorderSize = 0;
            this.btn_pagar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btn_pagar.ForeColor = System.Drawing.Color.White;
            this.btn_pagar.Location = new System.Drawing.Point(340, 10);
            this.btn_pagar.Name = "btn_pagar";
            this.btn_pagar.Size = new System.Drawing.Size(115, 168);
            this.btn_pagar.Text = "Finalizar\nVenta";
            this.btn_pagar.TabIndex = 2;
            this.btn_pagar.Click += new System.EventHandler(this.btn_pagar_Click);

            // ── UcVentas ──────────────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(229, 231, 235);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.panel_busqueda);
            this.Controls.Add(this.panel_carrito);
            this.Controls.Add(this.panel_cobro);
            this.Name = "UcVentas";
            this.Size = new System.Drawing.Size(990, 640);
            this.Load += new System.EventHandler(this.UcVentas_Load);
            this.panel_busqueda.ResumeLayout(false);
            this.panel_busqueda.PerformLayout();
            this.panel_carrito.ResumeLayout(false);
            this.panel_cobro.ResumeLayout(false);
            this.panel_cobro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_carrito)).EndInit();
            this.ResumeLayout(false);
        }

        // ── Helper para pares label / valor ───────────────────────────────────
        private void SetLabelPair(System.Windows.Forms.Label lbl, System.Windows.Forms.Label val,
                                  int x, int y, string titulo, string valorText)
        {
            lbl.AutoSize = false;
            lbl.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            lbl.ForeColor = System.Drawing.Color.FromArgb(80, 80, 80);
            lbl.Location = new System.Drawing.Point(x, y);
            lbl.Size = new System.Drawing.Size(150, 22);
            lbl.Text = titulo;

            if (val != null)
            {
                val.AutoSize = false;
                val.Font = new System.Drawing.Font("Segoe UI", 10F);
                val.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
                val.Location = new System.Drawing.Point(200, y);
                val.Size = new System.Drawing.Size(120, 22);
                val.Text = valorText;
                val.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            }
        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Panel panel_busqueda;
        private System.Windows.Forms.Label lbl_busqueda_titulo;
        private System.Windows.Forms.TextBox txb_busqueda;
        private System.Windows.Forms.ListView lv_productos;
        private System.Windows.Forms.ColumnHeader col_prod_nombre;
        private System.Windows.Forms.ColumnHeader col_prod_precio;
        private System.Windows.Forms.ColumnHeader col_prod_stock;
        private System.Windows.Forms.Button btn_agregar;
        private System.Windows.Forms.Panel panel_carrito;
        private System.Windows.Forms.Label lbl_carrito_titulo;
        private System.Windows.Forms.DataGridView dgv_carrito;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_c_nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_c_cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_c_precio;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_c_subtotal;
        private System.Windows.Forms.Button btn_quitar;
        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.Panel panel_cobro;
        private System.Windows.Forms.Label lbl_subtotal_lbl;
        private System.Windows.Forms.Label lbl_val_subtotal;
        private System.Windows.Forms.Label lbl_total_lbl;
        private System.Windows.Forms.Label lbl_val_total;
        private System.Windows.Forms.Label lbl_monto_lbl;
        private System.Windows.Forms.TextBox txb_monto_recibido;
        private System.Windows.Forms.Label lbl_cambio_lbl;
        private System.Windows.Forms.Label lbl_val_cambio;
        private System.Windows.Forms.Label lbl_metodo_lbl;
        private System.Windows.Forms.ComboBox cmb_metodo_pago;
        private System.Windows.Forms.Button btn_pagar;
    }
}
