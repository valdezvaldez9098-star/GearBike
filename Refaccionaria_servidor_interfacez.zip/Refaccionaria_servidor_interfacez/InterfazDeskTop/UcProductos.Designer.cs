namespace InterfazDeskTop
{
    partial class UcProductos
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.lbl_titulo = new System.Windows.Forms.Label();
            // barra de filtros
            this.panel_filtros = new System.Windows.Forms.Panel();
            this.txb_filtro = new System.Windows.Forms.TextBox();
            this.cmb_filtro_marca = new System.Windows.Forms.ComboBox();
            this.btn_nuevo = new System.Windows.Forms.Button();
            // tabla
            this.dgv_productos = new System.Windows.Forms.DataGridView();
            this.col_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_marca = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_stock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_acciones = new System.Windows.Forms.DataGridViewButtonColumn();
            // panel formulario lateral
            this.panel_form = new System.Windows.Forms.Panel();
            this.lbl_form_titulo = new System.Windows.Forms.Label();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.txb_nombre = new System.Windows.Forms.TextBox();
            this.lbl_precio_compra = new System.Windows.Forms.Label();
            this.txb_precio_compra = new System.Windows.Forms.TextBox();
            this.lbl_precio_venta = new System.Windows.Forms.Label();
            this.txb_precio_venta = new System.Windows.Forms.TextBox();
            this.lbl_stock = new System.Windows.Forms.Label();
            this.txb_stock = new System.Windows.Forms.TextBox();
            this.lbl_stock_min = new System.Windows.Forms.Label();
            this.txb_stock_min = new System.Windows.Forms.TextBox();
            this.lbl_marca_form = new System.Windows.Forms.Label();
            this.cmb_marca_form = new System.Windows.Forms.ComboBox();
            this.lbl_modelo = new System.Windows.Forms.Label();
            this.txb_modelo = new System.Windows.Forms.TextBox();
            this.lbl_codigo = new System.Windows.Forms.Label();
            this.txb_codigo_barras = new System.Windows.Forms.TextBox();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.btn_cancelar_form = new System.Windows.Forms.Button();
            this.btn_nueva_marca = new System.Windows.Forms.Button();
            // editar desde tabla
            this.btn_editar = new System.Windows.Forms.Button();

            this.panel_filtros.SuspendLayout();
            this.panel_form.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_productos)).BeginInit();
            this.SuspendLayout();

            // ── lbl_titulo ────────────────────────────────────────────────────
            this.lbl_titulo.AutoSize = false;
            this.lbl_titulo.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_titulo.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.lbl_titulo.Location = new System.Drawing.Point(30, 20);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(400, 45);
            this.lbl_titulo.Text = "Gestión de Productos";

            // ── panel_filtros ─────────────────────────────────────────────────
            this.panel_filtros.BackColor = System.Drawing.Color.Transparent;
            this.panel_filtros.Location = new System.Drawing.Point(30, 75);
            this.panel_filtros.Name = "panel_filtros";
            this.panel_filtros.Size = new System.Drawing.Size(620, 38);
            this.panel_filtros.TabIndex = 1;
            this.panel_filtros.Controls.Add(this.txb_filtro);
            this.panel_filtros.Controls.Add(this.cmb_filtro_marca);

            this.txb_filtro.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txb_filtro.Location = new System.Drawing.Point(0, 5);
            this.txb_filtro.Name = "txb_filtro";
            // PlaceholderText no está disponible en .NET Framework 4.x
            this.txb_filtro.Text = "Buscar producto...";
            this.txb_filtro.ForeColor = System.Drawing.Color.Gray;
            this.txb_filtro.GotFocus += (s, e) => {
                if (this.txb_filtro.Text == "Buscar producto...") {
                    this.txb_filtro.Text = "";
                    this.txb_filtro.ForeColor = System.Drawing.Color.Black;
                }
            };
            this.txb_filtro.LostFocus += (s, e) => {
                if (string.IsNullOrWhiteSpace(this.txb_filtro.Text)) {
                    this.txb_filtro.Text = "Buscar producto...";
                    this.txb_filtro.ForeColor = System.Drawing.Color.Gray;
                }
            };
            this.txb_filtro.Size = new System.Drawing.Size(260, 28);
            this.txb_filtro.TabIndex = 0;
            this.txb_filtro.TextChanged += new System.EventHandler(this.txb_filtro_TextChanged);

            this.cmb_filtro_marca.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_filtro_marca.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmb_filtro_marca.Items.Add("Todas las marcas");
            this.cmb_filtro_marca.Location = new System.Drawing.Point(275, 5);
            this.cmb_filtro_marca.Name = "cmb_filtro_marca";
            this.cmb_filtro_marca.SelectedIndex = 0;
            this.cmb_filtro_marca.Size = new System.Drawing.Size(200, 26);
            this.cmb_filtro_marca.TabIndex = 1;
            this.cmb_filtro_marca.SelectedIndexChanged += new System.EventHandler(this.cmb_filtro_marca_SelectedIndexChanged);

            // ── btn_nuevo ─────────────────────────────────────────────────────
            this.btn_nuevo.BackColor = System.Drawing.Color.FromArgb(249, 115, 22);
            this.btn_nuevo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_nuevo.FlatAppearance.BorderSize = 0;
            this.btn_nuevo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btn_nuevo.ForeColor = System.Drawing.Color.White;
            this.btn_nuevo.Location = new System.Drawing.Point(810, 80);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(140, 33);
            this.btn_nuevo.Text = "+ Nuevo Producto";
            this.btn_nuevo.TabIndex = 2;
            this.btn_nuevo.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.btn_nuevo.Click += new System.EventHandler(this.btn_nuevo_Click);

            // ── btn_editar ────────────────────────────────────────────────────
            this.btn_editar.BackColor = System.Drawing.Color.FromArgb(249, 115, 22);
            this.btn_editar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_editar.FlatAppearance.BorderSize = 0;
            this.btn_editar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_editar.ForeColor = System.Drawing.Color.White;
            this.btn_editar.Location = new System.Drawing.Point(660, 80);
            this.btn_editar.Name = "btn_editar";
            this.btn_editar.Size = new System.Drawing.Size(130, 33);
            this.btn_editar.Text = "✏ Editar";
            this.btn_editar.TabIndex = 3;
            this.btn_editar.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.btn_editar.Click += new System.EventHandler(this.btn_editar_Click);

            // ── dgv_productos ─────────────────────────────────────────────────
            this.dgv_productos.AllowUserToAddRows = false;
            this.dgv_productos.AllowUserToDeleteRows = false;
            this.dgv_productos.AllowUserToResizeRows = false;
            this.dgv_productos.BackgroundColor = System.Drawing.Color.White;
            this.dgv_productos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_productos.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.dgv_productos.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgv_productos.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.dgv_productos.ColumnHeadersDefaultCellStyle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.dgv_productos.ColumnHeadersHeight = 38;
            this.dgv_productos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_productos.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgv_productos.DefaultCellStyle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.dgv_productos.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(253, 186, 116);
            this.dgv_productos.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgv_productos.EnableHeadersVisualStyles = false;
            this.dgv_productos.GridColor = System.Drawing.Color.FromArgb(220, 220, 220);
            this.dgv_productos.Location = new System.Drawing.Point(30, 125);
            this.dgv_productos.Name = "dgv_productos";
            this.dgv_productos.ReadOnly = true;
            this.dgv_productos.RowHeadersVisible = false;
            this.dgv_productos.RowTemplate.Height = 34;
            this.dgv_productos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_productos.Size = new System.Drawing.Size(620, 480);
            this.dgv_productos.TabIndex = 4;
            this.dgv_productos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_productos_CellContentClick);
            this.dgv_productos.Anchor = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Bottom
                | System.Windows.Forms.AnchorStyles.Left;
            this.dgv_productos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.col_id, this.col_nombre, this.col_marca,
                this.col_precio, this.col_stock, this.col_acciones });

            this.col_id.HeaderText = "ID";
            this.col_id.Name = "col_id";
            this.col_id.Width = 55;
            this.col_nombre.HeaderText = "Nombre";
            this.col_nombre.Name = "col_nombre";
            this.col_nombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col_marca.HeaderText = "Marca";
            this.col_marca.Name = "col_marca";
            this.col_marca.Width = 110;
            this.col_precio.HeaderText = "Precio Venta";
            this.col_precio.Name = "col_precio";
            this.col_precio.Width = 105;
            this.col_stock.HeaderText = "Stock";
            this.col_stock.Name = "col_stock";
            this.col_stock.Width = 65;
            this.col_acciones.HeaderText = "Acciones";
            this.col_acciones.Name = "col_acciones";
            this.col_acciones.Width = 80;
            this.col_acciones.Text = "Editar";
            this.col_acciones.UseColumnTextForButtonValue = true;
            this.col_acciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;

            // ── panel_form ────────────────────────────────────────────────────
            this.panel_form.BackColor = System.Drawing.Color.White;
            this.panel_form.Location = new System.Drawing.Point(670, 125);
            this.panel_form.Name = "panel_form";
            this.panel_form.Size = new System.Drawing.Size(290, 480);
            this.panel_form.TabIndex = 5;
            this.panel_form.Anchor = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Bottom
                | System.Windows.Forms.AnchorStyles.Right;
            this.panel_form.Controls.Add(this.lbl_form_titulo);
            this.panel_form.Controls.Add(this.lbl_nombre);
            this.panel_form.Controls.Add(this.txb_nombre);
            this.panel_form.Controls.Add(this.lbl_precio_compra);
            this.panel_form.Controls.Add(this.txb_precio_compra);
            this.panel_form.Controls.Add(this.lbl_precio_venta);
            this.panel_form.Controls.Add(this.txb_precio_venta);
            this.panel_form.Controls.Add(this.lbl_stock);
            this.panel_form.Controls.Add(this.txb_stock);
            this.panel_form.Controls.Add(this.lbl_stock_min);
            this.panel_form.Controls.Add(this.txb_stock_min);
            this.panel_form.Controls.Add(this.lbl_marca_form);
            this.panel_form.Controls.Add(this.cmb_marca_form);
            this.panel_form.Controls.Add(this.lbl_modelo);
            this.panel_form.Controls.Add(this.txb_modelo);
            this.panel_form.Controls.Add(this.lbl_codigo);
            this.panel_form.Controls.Add(this.txb_codigo_barras);
            this.panel_form.Controls.Add(this.btn_guardar);
            this.panel_form.Controls.Add(this.btn_cancelar_form);
            this.panel_form.Controls.Add(this.btn_nueva_marca);

            // Título del formulario
            this.lbl_form_titulo.AutoSize = false;
            this.lbl_form_titulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_form_titulo.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.lbl_form_titulo.Location = new System.Drawing.Point(15, 15);
            this.lbl_form_titulo.Size = new System.Drawing.Size(260, 28);
            this.lbl_form_titulo.Text = "Nuevo / Editar Producto";

            // Campos del formulario
            int fy = 50;
            AgregarCampoForm(this.lbl_nombre, this.txb_nombre, "Nombre *", ref fy);
            AgregarCampoForm(this.lbl_precio_compra, this.txb_precio_compra, "Precio Compra", ref fy);
            AgregarCampoForm(this.lbl_precio_venta, this.txb_precio_venta, "Precio Venta *", ref fy);
            AgregarCampoForm(this.lbl_stock, this.txb_stock, "Stock Actual *", ref fy);
            AgregarCampoForm(this.lbl_stock_min, this.txb_stock_min, "Stock Mínimo", ref fy);

            // ComboBox marca — ancho reducido para dar espacio al botón "+"
            this.lbl_marca_form.AutoSize = false;
            this.lbl_marca_form.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lbl_marca_form.ForeColor = System.Drawing.Color.FromArgb(80, 80, 80);
            this.lbl_marca_form.Location = new System.Drawing.Point(15, fy);
            this.lbl_marca_form.Size = new System.Drawing.Size(260, 18);
            this.lbl_marca_form.Text = "Marca";
            fy += 20;
            this.cmb_marca_form.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_marca_form.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmb_marca_form.Location = new System.Drawing.Point(15, fy);
            this.cmb_marca_form.Name = "cmb_marca_form";
            this.cmb_marca_form.Size = new System.Drawing.Size(220, 26);   // reducido
            this.cmb_marca_form.TabIndex = 10;

            // Botón "+" para agregar marca nueva
            this.btn_nueva_marca.BackColor = System.Drawing.Color.FromArgb(249, 115, 22);
            this.btn_nueva_marca.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_nueva_marca.FlatAppearance.BorderSize = 0;
            this.btn_nueva_marca.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btn_nueva_marca.ForeColor = System.Drawing.Color.White;
            this.btn_nueva_marca.Location = new System.Drawing.Point(240, fy);
            this.btn_nueva_marca.Name = "btn_nueva_marca";
            this.btn_nueva_marca.Size = new System.Drawing.Size(33, 26);
            this.btn_nueva_marca.Text = "+";
            this.btn_nueva_marca.TabIndex = 11;
            this.btn_nueva_marca.Click += new System.EventHandler(this.btn_nueva_marca_Click);
            fy += 35;

            AgregarCampoForm(this.lbl_modelo, this.txb_modelo, "Modelo", ref fy);
            AgregarCampoForm(this.lbl_codigo, this.txb_codigo_barras, "Código de Barras", ref fy);

            // Botones guardar / cancelar
            fy += 5;
            this.btn_guardar.BackColor = System.Drawing.Color.FromArgb(34, 197, 94);
            this.btn_guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_guardar.FlatAppearance.BorderSize = 0;
            this.btn_guardar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btn_guardar.ForeColor = System.Drawing.Color.White;
            this.btn_guardar.Location = new System.Drawing.Point(15, fy);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(124, 34);
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.TabIndex = 20;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);

            this.btn_cancelar_form.BackColor = System.Drawing.Color.FromArgb(127, 140, 141);
            this.btn_cancelar_form.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancelar_form.FlatAppearance.BorderSize = 0;
            this.btn_cancelar_form.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btn_cancelar_form.ForeColor = System.Drawing.Color.White;
            this.btn_cancelar_form.Location = new System.Drawing.Point(149, fy);
            this.btn_cancelar_form.Name = "btn_cancelar_form";
            this.btn_cancelar_form.Size = new System.Drawing.Size(124, 34);
            this.btn_cancelar_form.Text = "Cancelar";
            this.btn_cancelar_form.TabIndex = 21;
            this.btn_cancelar_form.Click += new System.EventHandler(this.btn_cancelar_form_Click);

            // ── UcProductos ───────────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(229, 231, 235);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.panel_filtros);
            this.Controls.Add(this.btn_editar);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.dgv_productos);
            this.Controls.Add(this.panel_form);
            this.Name = "UcProductos";
            this.Size = new System.Drawing.Size(990, 640);
            this.Load += new System.EventHandler(this.UcProductos_Load);
            this.panel_filtros.ResumeLayout(false);
            this.panel_filtros.PerformLayout();
            this.panel_form.ResumeLayout(false);
            this.panel_form.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_productos)).EndInit();
            this.ResumeLayout(false);
        }

        // ── Helper: agrega un par Label + TextBox al panel del formulario ─────
        private int _tabIdx = 0;
        private void AgregarCampoForm(System.Windows.Forms.Label lbl,
                                      System.Windows.Forms.TextBox txb,
                                      string texto, ref int y)
        {
            lbl.AutoSize = false;
            lbl.Font = new System.Drawing.Font("Segoe UI", 9F);
            lbl.ForeColor = System.Drawing.Color.FromArgb(80, 80, 80);
            lbl.Location = new System.Drawing.Point(15, y);
            lbl.Size = new System.Drawing.Size(260, 18);
            lbl.Text = texto;
            y += 20;

            txb.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            txb.Location = new System.Drawing.Point(15, y);
            txb.Size = new System.Drawing.Size(258, 26);
            txb.TabIndex = _tabIdx++;
            y += 35;
        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Panel panel_filtros;
        private System.Windows.Forms.TextBox txb_filtro;
        private System.Windows.Forms.ComboBox cmb_filtro_marca;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.Button btn_editar;
        private System.Windows.Forms.DataGridView dgv_productos;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_marca;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_precio;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_stock;
        private System.Windows.Forms.DataGridViewButtonColumn col_acciones;
        private System.Windows.Forms.Panel panel_form;
        private System.Windows.Forms.Label lbl_form_titulo;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.TextBox txb_nombre;
        private System.Windows.Forms.Label lbl_precio_compra;
        private System.Windows.Forms.TextBox txb_precio_compra;
        private System.Windows.Forms.Label lbl_precio_venta;
        private System.Windows.Forms.TextBox txb_precio_venta;
        private System.Windows.Forms.Label lbl_stock;
        private System.Windows.Forms.TextBox txb_stock;
        private System.Windows.Forms.Label lbl_stock_min;
        private System.Windows.Forms.TextBox txb_stock_min;
        private System.Windows.Forms.Label lbl_marca_form;
        private System.Windows.Forms.ComboBox cmb_marca_form;
        private System.Windows.Forms.Label lbl_modelo;
        private System.Windows.Forms.TextBox txb_modelo;
        private System.Windows.Forms.Label lbl_codigo;
        private System.Windows.Forms.TextBox txb_codigo_barras;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Button btn_cancelar_form;
        private System.Windows.Forms.Button btn_nueva_marca;
    }
}
