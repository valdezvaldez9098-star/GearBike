using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazDeskTop
{
    /// <summary>
    /// Módulo Gestión de Productos: lista, filtrado, alta y edición.
    /// </summary>
    public partial class UcProductos : UserControl
    {
        // ── Estado ────────────────────────────────────────────────────────────
        private List<ProductoDto> _productos   = new List<ProductoDto>();
        private List<MarcaDto>    _marcas      = new List<MarcaDto>();
        private int               _editandoId  = 0;   // 0 = nuevo, >0 = edición

        public UcProductos()
        {
            InitializeComponent();
        }

        // ── Carga inicial ─────────────────────────────────────────────────────
        private void UcProductos_Load(object sender, EventArgs e)
        {
            _ = CargarDatos();
        }

        private async Task CargarDatos()
        {
            HabilitarControles(false);
            try
            {
                var taskMarcas    = ApiHelper.GetAsync<List<MarcaDto>>("api/Marcas");
                var taskProductos = ApiHelper.GetAsync<List<ProductoDto>>("api/Productos");

                await Task.WhenAll(taskMarcas, taskProductos);

                _marcas    = taskMarcas.Result    ?? new List<MarcaDto>();
                _productos = taskProductos.Result ?? new List<ProductoDto>();

                PopularComboMarcas();
                RefrescarTabla();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con la API:\n" + ex.Message,
                    "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                HabilitarControles(true);
            }
        }

        // ── Render de la tabla ────────────────────────────────────────────────
        private void RefrescarTabla()
        {
            string filtroTexto = txb_filtro.ForeColor == Color.Gray
                ? ""
                : txb_filtro.Text.Trim().ToLower();

            int filtroMarcaId = 0;
            if (cmb_filtro_marca.SelectedIndex > 0 && cmb_filtro_marca.SelectedItem is MarcaDto m)
                filtroMarcaId = m.IdMarca;

            var lista = _productos.AsEnumerable();

            if (!string.IsNullOrEmpty(filtroTexto))
                lista = lista.Where(p =>
                    p.Nombre.ToLower().Contains(filtroTexto) ||
                    (p.CodigoBarras ?? "").ToLower().Contains(filtroTexto));

            if (filtroMarcaId > 0)
                lista = lista.Where(p => p.FkMarca == filtroMarcaId);

            var resultado = lista.ToList();

            dgv_productos.Rows.Clear();

            if (resultado.Count == 0)
            {
                dgv_productos.Rows.Add("–", "No se encontraron productos", "", "", "", "");
                return;
            }

            var marcaMap = _marcas.ToDictionary(x => x.IdMarca, x => x.Nombre);

            foreach (var p in resultado)
            {
                int idx = dgv_productos.Rows.Add(
                    p.IdProducto,
                    p.Nombre,
                    marcaMap.TryGetValue(p.FkMarca, out var mn) ? mn : "N/A",
                    p.PrecioVenta.ToString("C2"),
                    p.StockActual,
                    "Editar"
                );

                bool bajo = p.StockActual <= (p.StockMinimo ?? 5);
                if (bajo)
                    dgv_productos.Rows[idx].DefaultCellStyle.BackColor = Color.FromArgb(255, 240, 240);
            }
        }

        // ── Filtros en tiempo real ────────────────────────────────────────────
        private void txb_filtro_TextChanged(object sender, EventArgs e)
        {
            if (txb_filtro.ForeColor == Color.Gray) return;
            RefrescarTabla();
        }

        private void cmb_filtro_marca_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefrescarTabla();
        }

        // ── Click en columna Editar de la tabla ───────────────────────────────
        private void dgv_productos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex != dgv_productos.Columns["col_acciones"].Index || e.RowIndex < 0)
                return;

            if (!int.TryParse(dgv_productos.Rows[e.RowIndex].Cells["col_id"].Value?.ToString(), out int id))
                return;

            AbrirFormulario(id);
        }

        // ── Botones ───────────────────────────────────────────────────────────
        private void btn_nueva_marca_Click(object sender, EventArgs e)
        {
            _ = AgregarMarca();
        }

        private async Task AgregarMarca()
        {
            // ── Mini-diálogo para el nombre de la nueva marca ─────────────────
            using (var dlg = new Form())
            {
                dlg.Text            = "Nueva Marca";
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.StartPosition   = FormStartPosition.CenterParent;
                dlg.Size            = new System.Drawing.Size(320, 150);
                dlg.MaximizeBox     = false;
                dlg.MinimizeBox     = false;

                var lbl = new Label
                {
                    Text      = "Nombre de la marca:",
                    Location  = new System.Drawing.Point(15, 18),
                    Size      = new System.Drawing.Size(280, 18),
                    Font      = new System.Drawing.Font("Segoe UI", 9F)
                };

                var txb = new TextBox
                {
                    Location  = new System.Drawing.Point(15, 40),
                    Size      = new System.Drawing.Size(278, 26),
                    Font      = new System.Drawing.Font("Segoe UI", 10F)
                };

                var btnOk = new Button
                {
                    Text          = "Guardar",
                    DialogResult  = DialogResult.OK,
                    Location      = new System.Drawing.Point(15, 75),
                    Size          = new System.Drawing.Size(130, 32),
                    BackColor     = System.Drawing.Color.FromArgb(39, 174, 96),
                    ForeColor     = System.Drawing.Color.White,
                    FlatStyle     = FlatStyle.Flat,
                    Font          = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold)
                };
                btnOk.FlatAppearance.BorderSize = 0;

                var btnCancel = new Button
                {
                    Text          = "Cancelar",
                    DialogResult  = DialogResult.Cancel,
                    Location      = new System.Drawing.Point(163, 75),
                    Size          = new System.Drawing.Size(130, 32),
                    BackColor     = System.Drawing.Color.FromArgb(127, 140, 141),
                    ForeColor     = System.Drawing.Color.White,
                    FlatStyle     = FlatStyle.Flat,
                    Font          = new System.Drawing.Font("Segoe UI", 10F)
                };
                btnCancel.FlatAppearance.BorderSize = 0;

                dlg.AcceptButton = btnOk;
                dlg.CancelButton = btnCancel;
                dlg.Controls.AddRange(new Control[] { lbl, txb, btnOk, btnCancel });

                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                string nombre = txb.Text.Trim();
                if (string.IsNullOrEmpty(nombre))
                {
                    MessageBox.Show("El nombre de la marca no puede estar vacío.",
                        "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Verificar duplicado localmente antes de ir a la API
                if (_marcas.Exists(m => m.Nombre.ToLower() == nombre.ToLower()))
                {
                    MessageBox.Show($"La marca '{nombre}' ya existe.",
                        "Duplicado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    var nueva = await ApiHelper.PostAsync<MarcaDto>(
                        "api/Marcas",
                        new MarcaDto { Nombre = nombre, Estatus = true }
                    );

                    // Agregar al estado local y refrescar combos sin recargar todo
                    _marcas.Add(nueva);
                    PopularComboMarcas();

                    // Seleccionar automáticamente la marca recién creada
                    for (int i = 0; i < cmb_marca_form.Items.Count; i++)
                    {
                        if (cmb_marca_form.Items[i] is MarcaDto m && m.IdMarca == nueva.IdMarca)
                        {
                            cmb_marca_form.SelectedIndex = i;
                            break;
                        }
                    }

                    MessageBox.Show($"Marca '{nombre}' creada con éxito.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al crear la marca:\n" + ex.Message,
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            AbrirFormulario(0);
        }

        private void btn_editar_Click(object sender, EventArgs e)
        {
            if (dgv_productos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un producto de la tabla para editar.",
                    "Sin selección", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(dgv_productos.SelectedRows[0].Cells["col_id"].Value?.ToString(), out int id))
                return;

            AbrirFormulario(id);
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            _ = GuardarProducto();
        }

        private void btn_cancelar_form_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }

        // ── Formulario lateral ────────────────────────────────────────────────
        private void AbrirFormulario(int id)
        {
            LimpiarFormulario();
            _editandoId = id;

            if (id == 0)
            {
                lbl_form_titulo.Text = "Nuevo Producto";
                return;
            }

            var p = _productos.FirstOrDefault(x => x.IdProducto == id);
            if (p == null) return;

            lbl_form_titulo.Text       = "Editar Producto";
            txb_nombre.Text            = p.Nombre;
            txb_precio_compra.Text     = p.PrecioCompra.ToString("F2");
            txb_precio_venta.Text      = p.PrecioVenta.ToString("F2");
            txb_stock.Text             = p.StockActual.ToString();
            txb_stock_min.Text         = p.StockMinimo?.ToString() ?? "";
            txb_modelo.Text            = p.Modelo ?? "";
            txb_codigo_barras.Text     = p.CodigoBarras ?? "";

            for (int i = 0; i < cmb_marca_form.Items.Count; i++)
            {
                if (cmb_marca_form.Items[i] is MarcaDto marca && marca.IdMarca == p.FkMarca)
                {
                    cmb_marca_form.SelectedIndex = i;
                    break;
                }
            }
        }

        private async Task GuardarProducto()
        {
            // Validaciones
            if (string.IsNullOrWhiteSpace(txb_nombre.Text))
            {
                MessageBox.Show("El nombre del producto es obligatorio.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txb_precio_venta.Text, out decimal precioVenta) || precioVenta <= 0)
            {
                MessageBox.Show("El precio de venta debe ser mayor a 0.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txb_stock.Text, out int stock) || stock < 0)
            {
                MessageBox.Show("El stock debe ser un número igual o mayor a 0.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmb_marca_form.SelectedItem == null)
            {
                MessageBox.Show("Selecciona una marca.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var marcaSel = (MarcaDto)cmb_marca_form.SelectedItem;
            decimal.TryParse(txb_precio_compra.Text, out decimal precioCompra);
            int.TryParse(txb_stock_min.Text, out int stockMin);

            var producto = new ProductoDto
            {
                IdProducto   = _editandoId,
                Nombre       = txb_nombre.Text.Trim(),
                PrecioCompra = precioCompra,
                PrecioVenta  = precioVenta,
                StockActual  = stock,
                StockMinimo  = string.IsNullOrWhiteSpace(txb_stock_min.Text) ? (int?)null : stockMin,
                Modelo       = string.IsNullOrWhiteSpace(txb_modelo.Text) ? null : txb_modelo.Text.Trim(),
                CodigoBarras = string.IsNullOrWhiteSpace(txb_codigo_barras.Text) ? null : txb_codigo_barras.Text.Trim(),
                FkMarca      = marcaSel.IdMarca,
                FkProveedor  = 1
            };

            HabilitarControles(false);
            try
            {
                if (_editandoId == 0)
                {
                    await ApiHelper.PostAsync<ProductoDto>("api/Productos", producto);
                    MessageBox.Show("Producto creado con éxito.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    await ApiHelper.PutAsync<object>($"api/Productos/{_editandoId}", producto);
                    MessageBox.Show("Producto actualizado con éxito.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                LimpiarFormulario();
                await CargarDatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar:\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                HabilitarControles(true);
            }
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private void PopularComboMarcas()
        {
            cmb_marca_form.Items.Clear();
            foreach (var m in _marcas)
                cmb_marca_form.Items.Add(m);
            cmb_marca_form.DisplayMember = "Nombre";

            cmb_filtro_marca.Items.Clear();
            cmb_filtro_marca.Items.Add("Todas las marcas");
            foreach (var m in _marcas)
                cmb_filtro_marca.Items.Add(m);
            cmb_filtro_marca.DisplayMember = "Nombre";
            cmb_filtro_marca.SelectedIndex = 0;
        }

        private void LimpiarFormulario()
        {
            _editandoId = 0;
            txb_nombre.Clear();
            txb_precio_compra.Clear();
            txb_precio_venta.Clear();
            txb_stock.Clear();
            txb_stock_min.Clear();
            txb_codigo_barras.Clear();
            txb_modelo.Clear();
            cmb_marca_form.SelectedIndex = -1;
            lbl_form_titulo.Text = "Nuevo / Editar Producto";
        }

        private void HabilitarControles(bool habilitar)
        {
            btn_guardar.Enabled   = habilitar;
            btn_nuevo.Enabled     = habilitar;
            btn_editar.Enabled    = habilitar;
            dgv_productos.Enabled = habilitar;
        }
    }
}
