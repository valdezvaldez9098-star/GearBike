using System;
using System.Drawing;
using System.Windows.Forms;

namespace InterfazDeskTop
{
    public partial class FrmPrincipal : Form
    {
        private UserControl _moduloActual;

        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            lbl_bienvenida.Text = "Bienvenido, " + UsuarioActual.NombreUsuario;
            timer_reloj.Interval = 1000;
            timer_reloj.Tick += (s, ev) => ActualizarReloj();
            timer_reloj.Start();
            ActualizarReloj();
            CargarModulo(new UcDashboard());
            MarcaBotonActivo(btn_nav_dashboard);
        }

        private void ActualizarReloj()
        {
            lbl_fecha_hora.Text = DateTime.Now.ToString("dd/MM/yyyy  HH:mm:ss");
        }

        // ── Navegación ────────────────────────────────────────────────────────
        private void btn_nav_dashboard_Click(object sender, EventArgs e)
        {
            CargarModulo(new UcDashboard());
            MarcaBotonActivo(btn_nav_dashboard);
        }

        private void btn_nav_ventas_Click(object sender, EventArgs e)
        {
            CargarModulo(new UcVentas());
            MarcaBotonActivo(btn_nav_ventas);
        }

        private void btn_nav_productos_Click(object sender, EventArgs e)
        {
            CargarModulo(new UcProductos());
            MarcaBotonActivo(btn_nav_productos);
        }

        private void btn_nav_cerrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Deseas cerrar sesión?", "Cerrar sesión",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                UsuarioActual.CerrarSesion();
                timer_reloj.Stop();
                this.Hide();
                new FrmLogin().ShowDialog();
                this.Close();
            }
        }

        private void CargarModulo(UserControl modulo)
        {
            if (_moduloActual != null)
            {
                panel_contenido.Controls.Remove(_moduloActual);
                _moduloActual.Dispose();
            }
            _moduloActual      = modulo;
            modulo.Dock        = DockStyle.Fill;
            panel_contenido.Controls.Add(modulo);
            modulo.BringToFront();
        }

        private void MarcaBotonActivo(Button activo)
        {
            Button[] todos = { btn_nav_dashboard, btn_nav_ventas,
                               btn_nav_productos, btn_nav_cerrar };
            foreach (var btn in todos)
            {
                btn.BackColor = GearBikeTheme.Navy;
                btn.ForeColor = Color.FromArgb(178, 190, 206);
                btn.Font      = GearBikeTheme.FontNormal;
            }
            activo.BackColor = GearBikeTheme.Orange;
            activo.ForeColor = GearBikeTheme.White;
            activo.Font      = GearBikeTheme.FontBold;
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            timer_reloj.Stop();
            base.OnFormClosed(e);
        }
    }
}
