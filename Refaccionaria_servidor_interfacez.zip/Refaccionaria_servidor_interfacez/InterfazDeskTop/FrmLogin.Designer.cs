using System.Drawing;
using System.Windows.Forms;

namespace InterfazDeskTop
{
    partial class FrmLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pb_logo        = new PictureBox();
            this.lbl_brand      = new Label();
            this.lbl_brand_sub  = new Label();
            this.lbl_usuario    = new Label();
            this.txt_usuario    = new TextBox();
            this.lbl_contrasena = new Label();
            this.txt_contrasena = new TextBox();
            this.btn_login      = new Button();
            this.btn_cancelar   = new Button();
            this.lbl_estado     = new Label();
            this.panel_card     = new Panel();

            this.panel_card.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)this.pb_logo).BeginInit();
            this.SuspendLayout();

            // ── Fondo del formulario ──────────────────────────────────────────
            this.BackColor = GearBikeTheme.Navy;

            // ── panel_card (tarjeta blanca centrada) ──────────────────────────
            this.panel_card.BackColor  = GearBikeTheme.White;
            this.panel_card.Location   = new Point(60, 30);
            this.panel_card.Size       = new Size(380, 410);
            this.panel_card.Controls.Add(this.pb_logo);
            this.panel_card.Controls.Add(this.lbl_brand);
            this.panel_card.Controls.Add(this.lbl_brand_sub);
            this.panel_card.Controls.Add(this.lbl_usuario);
            this.panel_card.Controls.Add(this.txt_usuario);
            this.panel_card.Controls.Add(this.lbl_contrasena);
            this.panel_card.Controls.Add(this.txt_contrasena);
            this.panel_card.Controls.Add(this.btn_login);
            this.panel_card.Controls.Add(this.btn_cancelar);
            this.panel_card.Controls.Add(this.lbl_estado);
            this.panel_card.Paint += (s, e) => {
                // Borde naranja superior
                using (var pen = new Pen(GearBikeTheme.Orange, 4))
                    e.Graphics.DrawLine(pen, 0, 0, this.panel_card.Width, 0);
            };

            // ── pb_logo ───────────────────────────────────────────────────────
            this.pb_logo.Image    = Image.FromFile("logo.png");
            this.pb_logo.SizeMode = PictureBoxSizeMode.Zoom;
            this.pb_logo.Location = new Point(140, 20);
            this.pb_logo.Size     = new Size(100, 85);
            this.pb_logo.BackColor = Color.Transparent;

            // ── lbl_brand ─────────────────────────────────────────────────────
            this.lbl_brand.AutoSize  = false;
            this.lbl_brand.Font      = new Font("Segoe UI", 20F, FontStyle.Bold);
            this.lbl_brand.ForeColor = GearBikeTheme.Navy;
            this.lbl_brand.Location  = new Point(0, 110);
            this.lbl_brand.Size      = new Size(380, 36);
            this.lbl_brand.Text      = "GearBike";
            this.lbl_brand.TextAlign = ContentAlignment.MiddleCenter;

            // ── lbl_brand_sub ─────────────────────────────────────────────────
            this.lbl_brand_sub.AutoSize  = false;
            this.lbl_brand_sub.Font      = new Font("Segoe UI", 9F);
            this.lbl_brand_sub.ForeColor = GearBikeTheme.TextMuted;
            this.lbl_brand_sub.Location  = new Point(0, 146);
            this.lbl_brand_sub.Size      = new Size(380, 18);
            this.lbl_brand_sub.Text      = "POS para Refacciones de Bicicletas";
            this.lbl_brand_sub.TextAlign = ContentAlignment.MiddleCenter;

            // ── lbl_usuario ───────────────────────────────────────────────────
            this.lbl_usuario.AutoSize  = false;
            this.lbl_usuario.Font      = GearBikeTheme.FontNormal;
            this.lbl_usuario.ForeColor = GearBikeTheme.Navy;
            this.lbl_usuario.Location  = new Point(30, 180);
            this.lbl_usuario.Size      = new Size(320, 20);
            this.lbl_usuario.Text      = "Usuario";

            // ── txt_usuario ───────────────────────────────────────────────────
            this.txt_usuario.Font      = GearBikeTheme.FontNormal;
            this.txt_usuario.Location  = new Point(30, 202);
            this.txt_usuario.Size      = new Size(320, 28);
            this.txt_usuario.BorderStyle = BorderStyle.FixedSingle;
            this.txt_usuario.TabIndex  = 0;

            // ── lbl_contrasena ────────────────────────────────────────────────
            this.lbl_contrasena.AutoSize  = false;
            this.lbl_contrasena.Font      = GearBikeTheme.FontNormal;
            this.lbl_contrasena.ForeColor = GearBikeTheme.Navy;
            this.lbl_contrasena.Location  = new Point(30, 242);
            this.lbl_contrasena.Size      = new Size(320, 20);
            this.lbl_contrasena.Text      = "Contraseña";

            // ── txt_contrasena ────────────────────────────────────────────────
            this.txt_contrasena.Font         = GearBikeTheme.FontNormal;
            this.txt_contrasena.Location     = new Point(30, 264);
            this.txt_contrasena.Size         = new Size(320, 28);
            this.txt_contrasena.PasswordChar = '●';
            this.txt_contrasena.BorderStyle  = BorderStyle.FixedSingle;
            this.txt_contrasena.TabIndex     = 1;

            // ── btn_login ─────────────────────────────────────────────────────
            this.btn_login.BackColor   = GearBikeTheme.Orange;
            this.btn_login.FlatStyle   = FlatStyle.Flat;
            this.btn_login.FlatAppearance.BorderSize = 0;
            this.btn_login.Font        = GearBikeTheme.FontBold;
            this.btn_login.ForeColor   = GearBikeTheme.White;
            this.btn_login.Location    = new Point(30, 314);
            this.btn_login.Size        = new Size(148, 36);
            this.btn_login.Text        = "Ingresar";
            this.btn_login.TabIndex    = 2;
            this.btn_login.Click      += new System.EventHandler(this.btn_login_Click);

            // ── btn_cancelar ──────────────────────────────────────────────────
            this.btn_cancelar.BackColor   = GearBikeTheme.Gray;
            this.btn_cancelar.FlatStyle   = FlatStyle.Flat;
            this.btn_cancelar.FlatAppearance.BorderSize = 0;
            this.btn_cancelar.Font        = GearBikeTheme.FontNormal;
            this.btn_cancelar.ForeColor   = GearBikeTheme.Navy;
            this.btn_cancelar.Location    = new Point(202, 314);
            this.btn_cancelar.Size        = new Size(148, 36);
            this.btn_cancelar.Text        = "Cancelar";
            this.btn_cancelar.TabIndex    = 3;
            this.btn_cancelar.Click      += new System.EventHandler(this.btn_cancelar_Click);

            // ── lbl_estado ────────────────────────────────────────────────────
            this.lbl_estado.AutoSize  = false;
            this.lbl_estado.Font      = GearBikeTheme.FontSmall;
            this.lbl_estado.ForeColor = GearBikeTheme.Green;
            this.lbl_estado.Location  = new Point(30, 362);
            this.lbl_estado.Size      = new Size(320, 32);
            this.lbl_estado.TextAlign = ContentAlignment.MiddleCenter;

            // ── FrmLogin ──────────────────────────────────────────────────────
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode       = AutoScaleMode.Font;
            this.ClientSize          = new Size(500, 470);
            this.Controls.Add(this.panel_card);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.Name            = "FrmLogin";
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.Text            = "GearBike — Iniciar Sesión";
            this.Load           += new System.EventHandler(this.FrmLogin_Load);

            this.panel_card.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)this.pb_logo).EndInit();
            this.ResumeLayout(false);
        }

        private PictureBox pb_logo;
        private Label      lbl_brand;
        private Label      lbl_brand_sub;
        private Label      lbl_usuario;
        private TextBox    txt_usuario;
        private Label      lbl_contrasena;
        private TextBox    txt_contrasena;
        private Button     btn_login;
        private Button     btn_cancelar;
        private Label      lbl_estado;
        private Panel      panel_card;
    }
}
