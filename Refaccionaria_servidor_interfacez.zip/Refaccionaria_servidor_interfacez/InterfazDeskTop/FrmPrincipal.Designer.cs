using System.Drawing;
using System.Windows.Forms;

namespace InterfazDeskTop
{
    partial class FrmPrincipal
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components       = new System.ComponentModel.Container();
            this.panel_sidebar    = new Panel();
            this.pb_logo          = new PictureBox();
            this.lbl_brand        = new Label();
            this.lbl_brand_sub    = new Label();
            this.btn_nav_dashboard = new Button();
            this.btn_nav_ventas   = new Button();
            this.btn_nav_productos = new Button();
            this.btn_nav_cerrar   = new Button();
            this.lbl_bienvenida   = new Label();
            this.panel_contenido  = new Panel();
            this.panel_topbar     = new Panel();
            this.lbl_fecha_hora   = new Label();
            this.timer_reloj      = new Timer(this.components);

            this.panel_sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)this.pb_logo).BeginInit();
            this.panel_topbar.SuspendLayout();
            this.SuspendLayout();

            // ── panel_sidebar ─────────────────────────────────────────────────
            this.panel_sidebar.BackColor = GearBikeTheme.Navy;
            this.panel_sidebar.Controls.Add(this.pb_logo);
            this.panel_sidebar.Controls.Add(this.lbl_brand);
            this.panel_sidebar.Controls.Add(this.lbl_brand_sub);
            this.panel_sidebar.Controls.Add(this.btn_nav_dashboard);
            this.panel_sidebar.Controls.Add(this.btn_nav_ventas);
            this.panel_sidebar.Controls.Add(this.btn_nav_productos);
            this.panel_sidebar.Controls.Add(this.btn_nav_cerrar);
            this.panel_sidebar.Controls.Add(this.lbl_bienvenida);
            this.panel_sidebar.Dock = DockStyle.Left;
            this.panel_sidebar.Size = new Size(220, 680);
            // Línea separadora inferior del header
            this.panel_sidebar.Paint += (s, e) => {
                using (var pen = new Pen(Color.FromArgb(40, 255, 255, 255), 1))
                    e.Graphics.DrawLine(pen, 0, 148, 220, 148);
            };

            // ── pb_logo ───────────────────────────────────────────────────────
            this.pb_logo.Image     = Image.FromFile("logo.png");
            this.pb_logo.SizeMode  = PictureBoxSizeMode.Zoom;
            this.pb_logo.Location  = new Point(60, 14);
            this.pb_logo.Size      = new Size(100, 76);
            this.pb_logo.BackColor = Color.Transparent;

            // ── lbl_brand ─────────────────────────────────────────────────────
            this.lbl_brand.AutoSize  = false;
            this.lbl_brand.Font      = new Font("Segoe UI", 18F, FontStyle.Bold);
            this.lbl_brand.ForeColor = GearBikeTheme.White;
            this.lbl_brand.Location  = new Point(0, 92);
            this.lbl_brand.Size      = new Size(220, 34);
            this.lbl_brand.Text      = "GearBike";
            this.lbl_brand.TextAlign = ContentAlignment.MiddleCenter;

            // ── lbl_brand_sub ─────────────────────────────────────────────────
            this.lbl_brand_sub.AutoSize  = false;
            this.lbl_brand_sub.Font      = GearBikeTheme.FontSmall;
            this.lbl_brand_sub.ForeColor = GearBikeTheme.GrayMid;
            this.lbl_brand_sub.Location  = new Point(0, 126);
            this.lbl_brand_sub.Size      = new Size(220, 18);
            this.lbl_brand_sub.Text      = "POS BICICLETAS";
            this.lbl_brand_sub.TextAlign = ContentAlignment.MiddleCenter;

            // ── Botones de navegación (helper) ────────────────────────────────
            CrearBtnNav(this.btn_nav_dashboard, "📊  Dashboard",  160, this.btn_nav_dashboard_Click);
            CrearBtnNav(this.btn_nav_ventas,    "🧾  Ventas",     215, this.btn_nav_ventas_Click);
            CrearBtnNav(this.btn_nav_productos, "📦  Productos",  270, this.btn_nav_productos_Click);
            CrearBtnNav(this.btn_nav_cerrar,    "🔓  Cerrar Sesión", 325, this.btn_nav_cerrar_Click);

            // ── lbl_bienvenida ────────────────────────────────────────────────
            this.lbl_bienvenida.AutoSize  = false;
            this.lbl_bienvenida.Font      = GearBikeTheme.FontSmall;
            this.lbl_bienvenida.ForeColor = GearBikeTheme.GrayMid;
            this.lbl_bienvenida.Location  = new Point(0, 630);
            this.lbl_bienvenida.Size      = new Size(220, 30);
            this.lbl_bienvenida.Text      = "Bienvenido, usuario";
            this.lbl_bienvenida.TextAlign = ContentAlignment.MiddleCenter;

            // ── panel_topbar ──────────────────────────────────────────────────
            this.panel_topbar.BackColor = GearBikeTheme.White;
            this.panel_topbar.Controls.Add(this.lbl_fecha_hora);
            this.panel_topbar.Dock     = DockStyle.None;
            this.panel_topbar.Location = new Point(220, 0);
            this.panel_topbar.Size     = new Size(980, 42);
            this.panel_topbar.Anchor   = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            this.panel_topbar.Paint   += new PaintEventHandler(this.panel_topbar_Paint);

            // ── lbl_fecha_hora ────────────────────────────────────────────────
            this.lbl_fecha_hora.AutoSize  = true;
            this.lbl_fecha_hora.Font      = GearBikeTheme.FontSmall;
            this.lbl_fecha_hora.ForeColor = GearBikeTheme.TextMuted;
            this.lbl_fecha_hora.Location  = new Point(800, 14);
            this.lbl_fecha_hora.Text      = "00/00/0000  00:00:00";
            this.lbl_fecha_hora.Anchor    = AnchorStyles.Top | AnchorStyles.Right;

            // ── panel_contenido ───────────────────────────────────────────────
            this.panel_contenido.BackColor = GearBikeTheme.Background;
            this.panel_contenido.Location  = new Point(220, 42);
            this.panel_contenido.Size      = new Size(980, 638);
            this.panel_contenido.Anchor    = AnchorStyles.Top | AnchorStyles.Bottom
                                           | AnchorStyles.Left | AnchorStyles.Right;

            // ── FrmPrincipal ──────────────────────────────────────────────────
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode       = AutoScaleMode.Font;
            this.ClientSize          = new Size(1200, 680);
            this.Controls.Add(this.panel_contenido);
            this.Controls.Add(this.panel_topbar);
            this.Controls.Add(this.panel_sidebar);
            this.MinimumSize = new Size(960, 600);
            this.Name        = "FrmPrincipal";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text        = "GearBike — POS Refaccionaria de Bicicletas";
            this.Load       += new System.EventHandler(this.FrmPrincipal_Load);

            this.panel_sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)this.pb_logo).EndInit();
            this.panel_topbar.ResumeLayout(false);
            this.panel_topbar.PerformLayout();
            this.ResumeLayout(false);
        }

        // ── Helper botón de navegación ────────────────────────────────────────
        private void CrearBtnNav(Button btn, string texto, int y,
                                 System.EventHandler handler)
        {
            btn.BackColor   = GearBikeTheme.Navy;
            btn.FlatStyle   = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize  = 0;
            btn.FlatAppearance.MouseOverBackColor = GearBikeTheme.NavyHover;
            btn.Font        = GearBikeTheme.FontNormal;
            btn.ForeColor   = Color.FromArgb(178, 190, 206);
            btn.Location    = new Point(0, y);
            btn.Size        = new Size(220, 48);
            btn.Text        = texto;
            btn.TextAlign   = ContentAlignment.MiddleLeft;
            btn.Padding     = new Padding(20, 0, 0, 0);
            btn.Click      += handler;
        }

        // ── Línea separadora topbar ───────────────────────────────────────────
        private void panel_topbar_Paint(object sender, PaintEventArgs e)
        {
            using (var pen = new Pen(GearBikeTheme.Gray, 1))
                e.Graphics.DrawLine(pen, 0, panel_topbar.Height - 1,
                                    panel_topbar.Width, panel_topbar.Height - 1);
        }

        private Panel      panel_sidebar;
        private PictureBox pb_logo;
        private Label      lbl_brand;
        private Label      lbl_brand_sub;
        private Label      lbl_bienvenida;
        private Panel      panel_contenido;
        private Panel      panel_topbar;
        private Label      lbl_fecha_hora;
        private Button     btn_nav_dashboard;
        private Button     btn_nav_ventas;
        private Button     btn_nav_productos;
        private Button     btn_nav_cerrar;
        private Timer      timer_reloj;
    }
}
