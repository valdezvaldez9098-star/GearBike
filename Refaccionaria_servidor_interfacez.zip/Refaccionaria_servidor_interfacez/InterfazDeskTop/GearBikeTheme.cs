using System.Drawing;

namespace InterfazDeskTop
{
    /// <summary>
    /// Paleta y fuentes centralizadas de GearBike.
    /// Cambia aquí para reflejar en toda la app.
    /// </summary>
    public static class GearBikeTheme
    {
        // ── Colores ──────────────────────────────────────────────────────────
        public static readonly Color Navy        = ColorTranslator.FromHtml("#1E293B");
        public static readonly Color NavyHover   = ColorTranslator.FromHtml("#2D3F57");
        public static readonly Color Orange      = ColorTranslator.FromHtml("#F97316");
        public static readonly Color OrangeLight = ColorTranslator.FromHtml("#FED7AA");
        public static readonly Color Gray        = ColorTranslator.FromHtml("#E5E7EB");
        public static readonly Color GrayMid     = ColorTranslator.FromHtml("#94A3B8");
        public static readonly Color White       = Color.White;
        public static readonly Color Green       = ColorTranslator.FromHtml("#22C55E");
        public static readonly Color Red         = ColorTranslator.FromHtml("#EF4444");
        public static readonly Color Background  = ColorTranslator.FromHtml("#F1F5F9");
        public static readonly Color TextMuted   = ColorTranslator.FromHtml("#64748B");

        // ── Fuentes ──────────────────────────────────────────────────────────
        public static readonly Font FontTitle   = new Font("Segoe UI", 22F, FontStyle.Bold);
        public static readonly Font FontHeading = new Font("Segoe UI", 14F, FontStyle.Bold);
        public static readonly Font FontBold    = new Font("Segoe UI", 10F, FontStyle.Bold);
        public static readonly Font FontNormal  = new Font("Segoe UI", 10F);
        public static readonly Font FontSmall   = new Font("Segoe UI",  8F);
    }
}
