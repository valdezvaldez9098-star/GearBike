namespace InterfazDeskTop
{
    partial class UcDashboard
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.lbl_titulo            = new System.Windows.Forms.Label();
            this.panel_cards           = new System.Windows.Forms.Panel();
            this.card_total_productos  = new System.Windows.Forms.Panel();
            this.lbl_val_total_productos = new System.Windows.Forms.Label();
            this.lbl_tit_total_productos = new System.Windows.Forms.Label();
            this.card_ventas_hoy       = new System.Windows.Forms.Panel();
            this.lbl_val_ventas_hoy    = new System.Windows.Forms.Label();
            this.lbl_tit_ventas_hoy    = new System.Windows.Forms.Label();
            this.card_bajo_stock       = new System.Windows.Forms.Panel();
            this.lbl_val_bajo_stock    = new System.Windows.Forms.Label();
            this.lbl_tit_bajo_stock    = new System.Windows.Forms.Label();
            this.card_marca_top        = new System.Windows.Forms.Panel();
            this.lbl_val_marca_top     = new System.Windows.Forms.Label();
            this.lbl_tit_marca_top     = new System.Windows.Forms.Label();
            // Fila central: gráfica + bajo stock
            this.panel_grafica_card    = new System.Windows.Forms.Panel();
            this.lbl_tit_grafica       = new System.Windows.Forms.Label();
            this.panel_grafica         = new System.Windows.Forms.Panel();
            this.panel_bajo_stock_card = new System.Windows.Forms.Panel();
            this.lbl_tit_bajo_tabla    = new System.Windows.Forms.Label();
            this.dgv_bajo_stock        = new System.Windows.Forms.DataGridView();
            this.col_bs_nombre         = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_bs_marca          = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_bs_stock          = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_bs_minimo         = new System.Windows.Forms.DataGridViewTextBoxColumn();
            // Últimas ventas
            this.lbl_titulo_ventas     = new System.Windows.Forms.Label();
            this.dgv_ventas            = new System.Windows.Forms.DataGridView();
            this.col_id                = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_fecha             = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_total             = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_estado            = new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.panel_cards.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ventas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_bajo_stock)).BeginInit();
            this.SuspendLayout();

            // ── lbl_titulo ────────────────────────────────────────────────────
            this.lbl_titulo.AutoSize = false;
            this.lbl_titulo.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_titulo.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.lbl_titulo.Location = new System.Drawing.Point(30, 20);
            this.lbl_titulo.Size = new System.Drawing.Size(300, 45);
            this.lbl_titulo.Text = "Dashboard";

            // ── panel_cards ───────────────────────────────────────────────────
            this.panel_cards.Location = new System.Drawing.Point(30, 75);
            this.panel_cards.Name = "panel_cards";
            this.panel_cards.Size = new System.Drawing.Size(930, 120);
            this.panel_cards.Anchor = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Left
                | System.Windows.Forms.AnchorStyles.Right;
            this.panel_cards.Controls.Add(this.card_total_productos);
            this.panel_cards.Controls.Add(this.card_ventas_hoy);
            this.panel_cards.Controls.Add(this.card_bajo_stock);
            this.panel_cards.Controls.Add(this.card_marca_top);

            int cardW = 220;
            CrearCard(this.card_total_productos, this.lbl_tit_total_productos,
                      this.lbl_val_total_productos, 0,       "Productos Totales", "...");
            CrearCard(this.card_ventas_hoy,       this.lbl_tit_ventas_hoy,
                      this.lbl_val_ventas_hoy,    cardW+10, "Ventas Hoy",         "...");
            CrearCard(this.card_bajo_stock,        this.lbl_tit_bajo_stock,
                      this.lbl_val_bajo_stock,    (cardW+10)*2, "Bajo Stock",     "...");
            CrearCard(this.card_marca_top,         this.lbl_tit_marca_top,
                      this.lbl_val_marca_top,     (cardW+10)*3, "Marca top",      "...");

            // ── panel_grafica_card ────────────────────────────────────────────
            this.panel_grafica_card.BackColor = System.Drawing.Color.White;
            this.panel_grafica_card.Location  = new System.Drawing.Point(30, 210);
            this.panel_grafica_card.Name      = "panel_grafica_card";
            this.panel_grafica_card.Size      = new System.Drawing.Size(450, 200);
            this.panel_grafica_card.Anchor    = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Left;

            this.lbl_tit_grafica.AutoSize  = false;
            this.lbl_tit_grafica.Font      = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_tit_grafica.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.lbl_tit_grafica.Location  = new System.Drawing.Point(15, 12);
            this.lbl_tit_grafica.Size      = new System.Drawing.Size(420, 24);
            this.lbl_tit_grafica.Text      = "Ventas — últimos 7 días";

            this.panel_grafica.BackColor   = System.Drawing.Color.White;
            this.panel_grafica.Location    = new System.Drawing.Point(10, 44);
            this.panel_grafica.Name        = "panel_grafica";
            this.panel_grafica.Size        = new System.Drawing.Size(430, 145);

            this.panel_grafica_card.Controls.Add(this.lbl_tit_grafica);
            this.panel_grafica_card.Controls.Add(this.panel_grafica);
            this.panel_grafica_card.Paint += (s, e) => {
                var pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(220,220,220), 1);
                e.Graphics.DrawRectangle(pen, 0, 0, this.panel_grafica_card.Width-1, this.panel_grafica_card.Height-1);
            };

            // ── panel_bajo_stock_card ─────────────────────────────────────────
            this.panel_bajo_stock_card.BackColor = System.Drawing.Color.White;
            this.panel_bajo_stock_card.Location  = new System.Drawing.Point(500, 210);
            this.panel_bajo_stock_card.Name      = "panel_bajo_stock_card";
            this.panel_bajo_stock_card.Size      = new System.Drawing.Size(460, 200);
            this.panel_bajo_stock_card.Anchor    = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Right;

            this.lbl_tit_bajo_tabla.AutoSize  = false;
            this.lbl_tit_bajo_tabla.Font      = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_tit_bajo_tabla.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.lbl_tit_bajo_tabla.Location  = new System.Drawing.Point(15, 12);
            this.lbl_tit_bajo_tabla.Size      = new System.Drawing.Size(430, 24);
            this.lbl_tit_bajo_tabla.Text      = "⚠ Productos con bajo stock";

            // dgv_bajo_stock
            EstilizarDgv(this.dgv_bajo_stock);
            this.dgv_bajo_stock.Location = new System.Drawing.Point(10, 44);
            this.dgv_bajo_stock.Size     = new System.Drawing.Size(440, 148);
            this.dgv_bajo_stock.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.col_bs_nombre, this.col_bs_marca, this.col_bs_stock, this.col_bs_minimo });

            this.col_bs_nombre.HeaderText = "Producto";
            this.col_bs_nombre.Name       = "col_bs_nombre";
            this.col_bs_nombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col_bs_marca.HeaderText  = "Marca";
            this.col_bs_marca.Name        = "col_bs_marca";
            this.col_bs_marca.Width       = 90;
            this.col_bs_stock.HeaderText  = "Stock";
            this.col_bs_stock.Name        = "col_bs_stock";
            this.col_bs_stock.Width       = 65;
            this.col_bs_minimo.HeaderText = "Mínimo";
            this.col_bs_minimo.Name       = "col_bs_minimo";
            this.col_bs_minimo.Width      = 65;

            this.panel_bajo_stock_card.Controls.Add(this.lbl_tit_bajo_tabla);
            this.panel_bajo_stock_card.Controls.Add(this.dgv_bajo_stock);
            this.panel_bajo_stock_card.Paint += (s, e) => {
                var pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(220,220,220), 1);
                e.Graphics.DrawRectangle(pen, 0, 0, this.panel_bajo_stock_card.Width-1, this.panel_bajo_stock_card.Height-1);
            };

            // ── lbl_titulo_ventas ─────────────────────────────────────────────
            this.lbl_titulo_ventas.AutoSize = false;
            this.lbl_titulo_ventas.Font     = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lbl_titulo_ventas.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.lbl_titulo_ventas.Location = new System.Drawing.Point(30, 425);
            this.lbl_titulo_ventas.Size     = new System.Drawing.Size(300, 30);
            this.lbl_titulo_ventas.Text     = "Últimas Ventas";

            // ── dgv_ventas ────────────────────────────────────────────────────
            EstilizarDgv(this.dgv_ventas);
            this.dgv_ventas.Location = new System.Drawing.Point(30, 460);
            this.dgv_ventas.Size     = new System.Drawing.Size(930, 155);
            this.dgv_ventas.Anchor   = System.Windows.Forms.AnchorStyles.Top
                | System.Windows.Forms.AnchorStyles.Bottom
                | System.Windows.Forms.AnchorStyles.Left
                | System.Windows.Forms.AnchorStyles.Right;
            this.dgv_ventas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.col_id, this.col_fecha, this.col_total, this.col_estado });

            this.col_id.HeaderText    = "ID Venta";
            this.col_id.Name          = "col_id";
            this.col_id.Width         = 90;
            this.col_fecha.HeaderText = "Fecha";
            this.col_fecha.Name       = "col_fecha";
            this.col_fecha.Width      = 200;
            this.col_total.HeaderText = "Total";
            this.col_total.Name       = "col_total";
            this.col_total.Width      = 130;
            this.col_estado.HeaderText      = "Estado";
            this.col_estado.Name            = "col_estado";
            this.col_estado.AutoSizeMode    = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;

            // ── UcDashboard ───────────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor           = System.Drawing.Color.FromArgb(229, 231, 235);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.panel_cards);
            this.Controls.Add(this.panel_grafica_card);
            this.Controls.Add(this.panel_bajo_stock_card);
            this.Controls.Add(this.lbl_titulo_ventas);
            this.Controls.Add(this.dgv_ventas);
            this.Name = "UcDashboard";
            this.Size = new System.Drawing.Size(990, 640);
            this.Load += new System.EventHandler(this.UcDashboard_Load);
            this.panel_cards.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ventas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_bajo_stock)).EndInit();
            this.ResumeLayout(false);
        }

        // ── Helpers de construcción ───────────────────────────────────────────
        private void CrearCard(System.Windows.Forms.Panel card,
                               System.Windows.Forms.Label lblTit,
                               System.Windows.Forms.Label lblVal,
                               int x, string titulo, string valor)
        {
            card.BackColor = System.Drawing.Color.White;
            card.Location  = new System.Drawing.Point(x, 0);
            card.Size      = new System.Drawing.Size(220, 115);

            lblTit.AutoSize  = false;
            lblTit.Font      = new System.Drawing.Font("Segoe UI", 9.5F);
            lblTit.ForeColor = System.Drawing.Color.FromArgb(120, 120, 120);
            lblTit.Location  = new System.Drawing.Point(15, 18);
            lblTit.Size      = new System.Drawing.Size(190, 22);
            lblTit.Text      = titulo;

            lblVal.AutoSize  = false;
            lblVal.Font      = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            lblVal.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
            lblVal.Location  = new System.Drawing.Point(15, 46);
            lblVal.Size      = new System.Drawing.Size(190, 50);
            lblVal.Text      = valor;

            card.Controls.Add(lblTit);
            card.Controls.Add(lblVal);
            card.Paint += (s, e) => {
                var pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(220,220,220), 1);
                e.Graphics.DrawRectangle(pen, 0, 0, card.Width-1, card.Height-1);
            };
        }

        private void EstilizarDgv(System.Windows.Forms.DataGridView dgv)
        {
            dgv.AllowUserToAddRows    = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToResizeRows = false;
            dgv.BackgroundColor       = System.Drawing.Color.White;
            dgv.BorderStyle           = System.Windows.Forms.BorderStyle.None;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(30, 41, 59);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font      = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            dgv.ColumnHeadersDefaultCellStyle.Padding   = new System.Windows.Forms.Padding(8, 0, 0, 0);
            dgv.ColumnHeadersHeight = 34;
            dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.DefaultCellStyle.Font        = new System.Drawing.Font("Segoe UI", 9.5F);
            dgv.DefaultCellStyle.Padding     = new System.Windows.Forms.Padding(8, 0, 0, 0);
            dgv.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(253, 186, 116);
            dgv.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            dgv.EnableHeadersVisualStyles = false;
            dgv.GridColor         = System.Drawing.Color.FromArgb(225, 225, 225);
            dgv.ReadOnly          = true;
            dgv.RowHeadersVisible = false;
            dgv.RowTemplate.Height = 32;
            dgv.SelectionMode     = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Panel panel_cards;
        private System.Windows.Forms.Panel card_total_productos;
        private System.Windows.Forms.Label lbl_val_total_productos;
        private System.Windows.Forms.Label lbl_tit_total_productos;
        private System.Windows.Forms.Panel card_ventas_hoy;
        private System.Windows.Forms.Label lbl_val_ventas_hoy;
        private System.Windows.Forms.Label lbl_tit_ventas_hoy;
        private System.Windows.Forms.Panel card_bajo_stock;
        private System.Windows.Forms.Label lbl_val_bajo_stock;
        private System.Windows.Forms.Label lbl_tit_bajo_stock;
        private System.Windows.Forms.Panel card_marca_top;
        private System.Windows.Forms.Label lbl_val_marca_top;
        private System.Windows.Forms.Label lbl_tit_marca_top;
        private System.Windows.Forms.Panel panel_grafica_card;
        private System.Windows.Forms.Label lbl_tit_grafica;
        private System.Windows.Forms.Panel panel_grafica;
        private System.Windows.Forms.Panel panel_bajo_stock_card;
        private System.Windows.Forms.Label lbl_tit_bajo_tabla;
        private System.Windows.Forms.DataGridView dgv_bajo_stock;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_bs_nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_bs_marca;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_bs_stock;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_bs_minimo;
        private System.Windows.Forms.Label lbl_titulo_ventas;
        private System.Windows.Forms.DataGridView dgv_ventas;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_total;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_estado;
    }
}
