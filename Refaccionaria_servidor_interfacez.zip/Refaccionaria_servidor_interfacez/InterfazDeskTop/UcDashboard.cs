using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazDeskTop
{
    public partial class UcDashboard : UserControl
    {
        private List<ProductoDto> _productos = new List<ProductoDto>();
        private List<VentaDto>    _ventas    = new List<VentaDto>();

        public UcDashboard()
        {
            InitializeComponent();
        }

        private void UcDashboard_Load(object sender, EventArgs e)
        {
            _ = CargarDatos();
        }

        // ── Carga principal ───────────────────────────────────────────────────
        private async Task CargarDatos()
        {
            MostrarCargando(true);
            try
            {
                var taskProductos = ApiHelper.GetAsync<List<ProductoDto>>("api/Productos");
                var taskVentas    = ApiHelper.GetAsync<List<VentaDto>>("api/Ventas");
                await Task.WhenAll(taskProductos, taskVentas);

                _productos = taskProductos.Result ?? new List<ProductoDto>();
                _ventas    = taskVentas.Result    ?? new List<VentaDto>();

                RenderMetricas();
                RenderUltimasVentas();
                RenderGrafica();
                RenderBajoStock();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar el dashboard:\n" + ex.Message,
                    "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                MostrarCargando(false);
            }
        }

        // ── Métricas ──────────────────────────────────────────────────────────
        private void RenderMetricas()
        {
            lbl_val_total_productos.Text = _productos.Count.ToString();

            int bajo = _productos.Count(p => p.StockActual <= (p.StockMinimo ?? 5));
            lbl_val_bajo_stock.Text      = bajo.ToString();
            lbl_val_bajo_stock.ForeColor = bajo > 0
                ? Color.FromArgb(192, 57, 43)
                : Color.FromArgb(39, 174, 96);

            // FechaHora llega como "2026-05-17T13:59:38.4178358"
            // Comparamos solo los primeros 10 chars (yyyy-MM-dd)
            string hoy       = DateTime.Now.ToString("yyyy-MM-dd");
            var ventasHoy    = _ventas.Where(v =>
                v.FechaHora.Length >= 10 && v.FechaHora.Substring(0, 10) == hoy).ToList();
            decimal montoHoy = ventasHoy.Sum(v => v.Total);

            lbl_val_ventas_hoy.Text = montoHoy == 0 ? "$0" : montoHoy.ToString("C0");

            var marcaTop = _productos
                .Where(p => p.Marca != null)
                .GroupBy(p => p.Marca.Nombre)
                .OrderByDescending(g => g.Count())
                .Select(g => g.Key)
                .FirstOrDefault();
            lbl_val_marca_top.Text = marcaTop ?? "—";
            lbl_val_marca_top.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        }

        // ── Últimas 5 ventas ──────────────────────────────────────────────────
        private void RenderUltimasVentas()
        {
            dgv_ventas.Rows.Clear();

            var ultimas = _ventas.Take(5).ToList();

            if (ultimas.Count == 0)
            {
                dgv_ventas.Rows.Add("—", "No hay ventas registradas", "", "");
                return;
            }

            foreach (var v in ultimas)
            {
                // Formatear "2026-05-17T13:59:38.4178358" → "17/05/2026  13:59"
                string fecha = FormatearFecha(v.FechaHora);
                string estado = v.Estado ? "Completada" : "Cancelada";

                int idx = dgv_ventas.Rows.Add($"#{v.IdVenta}", fecha, v.Total.ToString("C2"), estado);
                dgv_ventas.Rows[idx].DefaultCellStyle.ForeColor = v.Estado
                    ? Color.FromArgb(39, 174, 96)
                    : Color.FromArgb(192, 57, 43);
            }
        }

        // ── Gráfica de barras — últimos 7 días ────────────────────────────────
        private void RenderGrafica()
        {
            panel_grafica.Controls.Clear();

            var dias = new List<(string Key, string Label, decimal Monto)>();
            for (int i = 6; i >= 0; i--)
            {
                var fecha  = DateTime.Now.AddDays(-i);
                string key = fecha.ToString("yyyy-MM-dd");
                decimal monto = _ventas
                    .Where(v => v.FechaHora.Length >= 10 && v.FechaHora.Substring(0, 10) == key)
                    .Sum(v => v.Total);
                dias.Add((key, fecha.ToString("dd/MM"), monto));
            }

            decimal maxMonto = dias.Max(d => d.Monto);
            if (maxMonto == 0) maxMonto = 1;

            int grafH  = panel_grafica.Height - 42;
            int barW   = (panel_grafica.Width - 20) / 7;
            int left   = 10;

            for (int i = 0; i < dias.Count; i++)
            {
                var (key, label, monto) = dias[i];
                int  barH  = Math.Max((int)(monto / maxMonto * grafH), monto > 0 ? 3 : 1);
                bool esHoy = i == 6;

                var barra = new Panel
                {
                    BackColor = esHoy
                        ? Color.FromArgb(46, 204, 113)
                        : Color.FromArgb(52, 152, 219),
                    Location  = new Point(left + i * barW + 4, grafH - barH),
                    Size      = new Size(barW - 8, barH)
                };
                var tip = new ToolTip();
                tip.SetToolTip(barra, $"{label}: {monto:C2}");

                var lblFecha = new Label
                {
                    Text      = label,
                    Font      = new Font("Segoe UI", 7.5F),
                    ForeColor = Color.FromArgb(120, 120, 120),
                    Location  = new Point(left + i * barW, grafH + 4),
                    Size      = new Size(barW, 18),
                    TextAlign = ContentAlignment.MiddleCenter
                };

                if (monto > 0)
                {
                    string valTxt = monto >= 1000
                        ? $"{monto / 1000:0.#}k"
                        : monto.ToString("0");
                    var lblVal = new Label
                    {
                        Text      = valTxt,
                        Font      = new Font("Segoe UI", 7F),
                        ForeColor = Color.FromArgb(90, 90, 90),
                        Location  = new Point(left + i * barW, grafH - barH - 16),
                        Size      = new Size(barW, 16),
                        TextAlign = ContentAlignment.MiddleCenter
                    };
                    panel_grafica.Controls.Add(lblVal);
                }

                panel_grafica.Controls.Add(barra);
                panel_grafica.Controls.Add(lblFecha);
            }
        }

        // ── Bajo stock ────────────────────────────────────────────────────────
        private void RenderBajoStock()
        {
            dgv_bajo_stock.Rows.Clear();

            var bajo = _productos
                .Where(p => p.StockActual <= (p.StockMinimo ?? 5))
                .OrderBy(p => p.StockActual)
                .Take(8)
                .ToList();

            if (bajo.Count == 0)
            {
                int idx = dgv_bajo_stock.Rows.Add("✔", "Todos tienen stock suficiente", "", "");
                dgv_bajo_stock.Rows[idx].DefaultCellStyle.ForeColor = Color.FromArgb(39, 174, 96);
                return;
            }

            foreach (var p in bajo)
            {
                bool agotado = p.StockActual == 0;
                int idx = dgv_bajo_stock.Rows.Add(
                    p.Nombre,
                    p.Marca?.Nombre ?? "N/A",
                    agotado ? "Agotado" : p.StockActual.ToString(),
                    p.StockMinimo?.ToString() ?? "5"
                );
                var row = dgv_bajo_stock.Rows[idx];
                row.DefaultCellStyle.BackColor = agotado
                    ? Color.FromArgb(255, 235, 235)
                    : Color.FromArgb(255, 248, 230);
                row.Cells[2].Style.ForeColor = agotado
                    ? Color.FromArgb(192, 57, 43)
                    : Color.FromArgb(211, 84, 0);
                row.Cells[2].Style.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            }
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private string FormatearFecha(string iso)
        {
            // "2026-05-17T13:59:38.4178358" → "17/05/2026  13:59"
            if (string.IsNullOrEmpty(iso) || iso.Length < 16) return iso;
            try
            {
                string[] partes = iso.Split('T');
                string[] fecha  = partes[0].Split('-');          // [yyyy, MM, dd]
                string   hora   = partes[1].Substring(0, 5);    // HH:mm
                return $"{fecha[2]}/{fecha[1]}/{fecha[0]}  {hora}";
            }
            catch { return iso; }
        }

        private void MostrarCargando(bool cargando)
        {
            if (!cargando) return;
            lbl_val_total_productos.Text = "...";
            lbl_val_ventas_hoy.Text      = "...";
            lbl_val_bajo_stock.Text      = "...";
            lbl_val_marca_top.Text       = "...";
        }

        public void Refrescar() => _ = CargarDatos();
    }
}
