using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazDeskTop
{
    public partial class UcVentas : UserControl
    {
        // ── Estado ────────────────────────────────────────────────────────────
        private List<CarritoItem>  _carrito   = new List<CarritoItem>();
        private List<ProductoDto>  _productos  = new List<ProductoDto>();
        private List<ProductoDto>  _filtrados  = new List<ProductoDto>();

        public UcVentas()
        {
            InitializeComponent();
        }

        // ── Carga inicial ─────────────────────────────────────────────────────
        private void UcVentas_Load(object sender, EventArgs e)
        {
            _ = CargarProductos();
            ActualizarTotales();
        }

        private async Task CargarProductos()
        {
            lv_productos.Items.Clear();
            lv_productos.Items.Add(new ListViewItem(new[] { "Cargando...", "", "" }));
            try
            {
                _productos = await ApiHelper.GetAsync<List<ProductoDto>>("api/Productos")
                             ?? new List<ProductoDto>();
                FiltrarYMostrar(txb_busqueda.ForeColor == Color.Gray ? "" : txb_busqueda.Text);
            }
            catch (Exception ex)
            {
                lv_productos.Items.Clear();
                lv_productos.Items.Add(new ListViewItem(new[] { "Error: " + ex.Message, "", "" }));
            }
        }

        // ── Búsqueda / filtrado ───────────────────────────────────────────────
        private void txb_busqueda_TextChanged(object sender, EventArgs e)
        {
            if (txb_busqueda.ForeColor == Color.Gray) return;
            FiltrarYMostrar(txb_busqueda.Text);
        }

        private void FiltrarYMostrar(string texto)
        {
            string filtro = (texto ?? "").Trim().ToLower();

            _filtrados = string.IsNullOrEmpty(filtro)
                ? _productos.ToList()
                : _productos.Where(p =>
                    p.Nombre.ToLower().Contains(filtro) ||
                    (p.CodigoBarras ?? "").ToLower().Contains(filtro)).ToList();

            lv_productos.Items.Clear();
            foreach (var p in _filtrados)
            {
                var item = new ListViewItem(new[]
                {
                    p.Nombre,
                    p.PrecioVenta.ToString("C2"),
                    p.StockActual.ToString()
                });
                item.Tag = p.IdProducto;

                // Resaltar en rojo si no hay stock
                if (p.StockActual <= 0)
                    item.ForeColor = Color.FromArgb(192, 57, 43);

                lv_productos.Items.Add(item);
            }
        }

        // ── Agregar al carrito ────────────────────────────────────────────────
        private void lv_productos_DoubleClick(object sender, EventArgs e)
        {
            AgregarProductoSeleccionado();
        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {
            AgregarProductoSeleccionado();
        }

        private void AgregarProductoSeleccionado()
        {
            if (lv_productos.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecciona un producto de la lista.",
                    "Sin selección", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int idProducto = (int)lv_productos.SelectedItems[0].Tag;
            var producto   = _productos.FirstOrDefault(p => p.IdProducto == idProducto);
            if (producto == null) return;

            if (producto.StockActual <= 0)
            {
                MessageBox.Show($"'{producto.Nombre}' no tiene stock disponible.",
                    "Sin stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var existente = _carrito.FirstOrDefault(c => c.IdProducto == idProducto);
            if (existente != null)
            {
                if (existente.Cantidad + 1 > producto.StockActual)
                {
                    MessageBox.Show($"Stock insuficiente. Solo quedan {producto.StockActual} unidades.",
                        "Stock insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                existente.Cantidad++;
            }
            else
            {
                _carrito.Add(new CarritoItem
                {
                    IdProducto     = producto.IdProducto,
                    Nombre         = producto.Nombre,
                    PrecioUnitario = producto.PrecioVenta,
                    Cantidad       = 1
                });
            }

            RefrescarCarrito();
        }

        // ── Quitar del carrito ────────────────────────────────────────────────
        private void btn_quitar_Click(object sender, EventArgs e)
        {
            if (dgv_carrito.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un producto del carrito para quitarlo.",
                    "Sin selección", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int idx = dgv_carrito.SelectedRows[0].Index;
            if (idx >= 0 && idx < _carrito.Count)
            {
                _carrito.RemoveAt(idx);
                RefrescarCarrito();
            }
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            if (_carrito.Count == 0) return;
            if (MessageBox.Show("¿Limpiar todo el carrito?", "Confirmar",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _carrito.Clear();
                RefrescarCarrito();
            }
        }

        // ── Cambio ────────────────────────────────────────────────────────────
        private void txb_monto_recibido_TextChanged(object sender, EventArgs e)
        {
            CalcularCambio();
        }

        private void CalcularCambio()
        {
            decimal total = _carrito.Sum(i => i.Subtotal);

            if (decimal.TryParse(txb_monto_recibido.Text, out decimal monto))
            {
                decimal cambio = monto - total;
                lbl_val_cambio.Text = cambio >= 0
                    ? cambio.ToString("C2")
                    : $"Faltan {Math.Abs(cambio):C2}";
                lbl_val_cambio.ForeColor = cambio >= 0
                    ? Color.FromArgb(39, 174, 96)
                    : Color.FromArgb(192, 57, 43);
            }
            else
            {
                lbl_val_cambio.Text      = "$0.00";
                lbl_val_cambio.ForeColor = Color.FromArgb(39, 174, 96);
            }
        }

        // ── Finalizar venta ───────────────────────────────────────────────────
        private void btn_pagar_Click(object sender, EventArgs e)
        {
            _ = FinalizarVenta();
        }

        private async Task FinalizarVenta()
        {
            // Validaciones previas
            if (_carrito.Count == 0)
            {
                MessageBox.Show("Agrega productos al carrito antes de cobrar.",
                    "Carrito vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal total = _carrito.Sum(i => i.Subtotal);
            string metodoPago = cmb_metodo_pago.SelectedItem?.ToString() ?? "Efectivo";

            decimal montoRecibido = total; // para tarjeta/transferencia se cobra exacto
            if (metodoPago == "Efectivo")
            {
                if (!decimal.TryParse(txb_monto_recibido.Text, out montoRecibido) || montoRecibido <= 0)
                {
                    MessageBox.Show("Ingresa el monto recibido.",
                        "Monto requerido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (montoRecibido < total)
                {
                    MessageBox.Show($"El monto recibido ({montoRecibido:C2}) es menor al total ({total:C2}).",
                        "Monto insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            decimal cambio = metodoPago == "Efectivo" ? montoRecibido - total : 0;

            // Construir el request
            var request = new VentaRequest
            {
                Venta = new VentaDto
                {
                    // FechaHora la asigna la API con DateTime.Now del servidor
                    Subtotal         = total,
                    Total            = total,
                    MontoRecibido    = montoRecibido,
                    CambioEntregado  = cambio,
                    MetodoPago       = metodoPago,
                    Estado           = true
                },
                Detalles = _carrito.Select(c => new DetalleVentaDto
                {
                    FkProducto           = c.IdProducto,
                    Cantidad             = c.Cantidad,
                    PrecioUnitarioVenta  = c.PrecioUnitario,
                    Subtotal             = c.Subtotal
                }).ToList()
            };

            // Deshabilitar botón para evitar doble cobro
            btn_pagar.Enabled = false;
            btn_pagar.Text    = "Procesando...";

            try
            {
                await ApiHelper.PostAsync<object>("api/Ventas", request);

                // Mostrar cambio si es efectivo
                string msg = metodoPago == "Efectivo" && cambio > 0
                    ? $"Venta registrada con éxito.\nCambio a entregar: {cambio:C2}"
                    : "Venta registrada con éxito.";

                MessageBox.Show(msg, "Venta completada",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Limpiar para la siguiente venta
                _carrito.Clear();
                txb_monto_recibido.Text = "0";
                RefrescarCarrito();

                // Recargar stock actualizado
                await CargarProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar la venta:\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btn_pagar.Enabled = true;
                btn_pagar.Text    = "Finalizar\nVenta";
            }
        }

        // ── Helpers de UI ─────────────────────────────────────────────────────
        private void RefrescarCarrito()
        {
            dgv_carrito.Rows.Clear();
            foreach (var item in _carrito)
            {
                dgv_carrito.Rows.Add(
                    item.Nombre,
                    item.Cantidad,
                    item.PrecioUnitario.ToString("C2"),
                    item.Subtotal.ToString("C2")
                );
            }
            ActualizarTotales();
        }

        private void ActualizarTotales()
        {
            decimal subtotal = _carrito.Sum(i => i.Subtotal);
            lbl_val_subtotal.Text = subtotal.ToString("C2");
            lbl_val_total.Text    = subtotal.ToString("C2");
            CalcularCambio();
        }
    }
}
