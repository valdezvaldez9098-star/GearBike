using System;
using System.Collections.Generic;

namespace InterfazDeskTop
{
    // ── Producto ────────────────────────────────────────────────────────────
    public class ProductoDto
    {
        public int IdProducto { get; set; }
        public string Nombre { get; set; } = "";
        public decimal PrecioCompra { get; set; }
        public decimal PrecioVenta { get; set; }
        public int FkMarca { get; set; }
        public int FkProveedor { get; set; }
        public int? FkTipoProducto { get; set; }
        public string Modelo { get; set; }
        public int StockActual { get; set; }
        public int? StockMinimo { get; set; }
        public int? StockMaximo { get; set; }
        public string CodigoBarras { get; set; }
        public MarcaDto Marca { get; set; }
    }

    // ── Marca ───────────────────────────────────────────────────────────────
    public class MarcaDto
    {
        public int IdMarca { get; set; }
        public string Nombre { get; set; } = "";
        public bool Estatus { get; set; }
    }

    // ── TipoProducto ─────────────────────────────────────────────────────────
    public class TipoProductoDto
    {
        public int IdTipoProducto { get; set; }
        public string Nombre { get; set; } = "";
        public bool Estado { get; set; }
    }

    // ── Proveedor ────────────────────────────────────────────────────────────
    public class ProveedorDto
    {
        public int IdProveedor { get; set; }
        public string Nombre { get; set; } = "";
        public bool Estado { get; set; }
    }

    // ── Venta ────────────────────────────────────────────────────────────────
    public class VentaDto
    {
        public int IdVenta { get; set; }

        // IMPORTANTE: el nombre debe ser "FechaHora" (no FechaHoraStr) para
        // que JavaScriptSerializer lo mapee desde el JSON "fechaHora" de la API.
        // Se declara como string para evitar el problema de conversión DateTime
        // entre .NET Framework 4.x y .NET 8.
        public string FechaHora { get; set; } = "";

        public decimal Subtotal { get; set; }
        public decimal Total { get; set; }
        public decimal MontoRecibido { get; set; }
        public decimal CambioEntregado { get; set; }
        public string MetodoPago { get; set; } = "";
        public bool Estado { get; set; }
    }

    // ── DetalleVenta ─────────────────────────────────────────────────────────
    public class DetalleVentaDto
    {
        public int FkProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnitarioVenta { get; set; }
        public decimal Subtotal { get; set; }
    }

    // ── Request de venta ──────────────────────────────────────────────────────
    public class VentaRequest
    {
        public VentaDto Venta { get; set; }
        public List<DetalleVentaDto> Detalles { get; set; }
    }

    // ── Ítem del carrito (solo en memoria) ────────────────────────────────────
    public class CarritoItem
    {
        public int IdProducto { get; set; }
        public string Nombre { get; set; } = "";
        public decimal PrecioUnitario { get; set; }
        public int Cantidad { get; set; }
        public decimal Subtotal => PrecioUnitario * Cantidad;
    }
}
