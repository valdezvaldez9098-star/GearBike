using Domain;
using Microsoft.EntityFrameworkCore;

namespace infraestructura
{
    public class RefaccionariaDbContext : DbContext
    {
        public RefaccionariaDbContext(DbContextOptions<RefaccionariaDbContext> options) : base(options)
        {
        }

        public DbSet<Producto>     Productos      { get; set; }
        public DbSet<Venta>        Ventas         { get; set; }
        public DbSet<DetalleVenta> DetallesVentas { get; set; }
        public DbSet<Proveedor>    Proveedores    { get; set; }
        public DbSet<Marca>        Marcas         { get; set; }
        public DbSet<TipoProducto> TiposProductos { get; set; }
        public DbSet<Usuario>      Usuarios       { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ── Usuarios ──────────────────────────────────────────────────────
            modelBuilder.Entity<Usuario>()
                .HasIndex(u => u.NombreUsuario)
                .IsUnique();

            // ── Producto → Marca ──────────────────────────────────────────────
            // Mapear la navegación Marca a la FK real FkMarca,
            // evitando que EF genere la columna shadow MarcaIdMarca
            modelBuilder.Entity<Producto>()
                .HasOne(p => p.Marca)
                .WithMany()
                .HasForeignKey(p => p.FkMarca)
                .HasConstraintName("FK_Productos_Marcas_FkMarca")
                .OnDelete(DeleteBehavior.Restrict);

            // ── Producto → Proveedor ──────────────────────────────────────────
            modelBuilder.Entity<Producto>()
                .HasOne(p => p.Proveedor)
                .WithMany()
                .HasForeignKey(p => p.FkProveedor)
                .HasConstraintName("FK_Productos_Proveedores_FkProveedor")
                .OnDelete(DeleteBehavior.Restrict);

            // ── Producto → TipoProducto ───────────────────────────────────────
            modelBuilder.Entity<Producto>()
                .HasOne(p => p.TipoProducto)
                .WithMany()
                .HasForeignKey(p => p.FkTipoProducto)
                .HasConstraintName("FK_Productos_TiposProductos_FkTipoProducto")
                .OnDelete(DeleteBehavior.Restrict);

            // ── DetalleVenta → Venta ──────────────────────────────────────────
            // Mapear la navegación Venta a FkVenta,
            // evitando que EF genere la columna shadow VentaIdVenta
            modelBuilder.Entity<DetalleVenta>()
                .HasOne(d => d.Venta)
                .WithMany()
                .HasForeignKey(d => d.FkVenta)
                .HasConstraintName("FK_DetallesVentas_Ventas_FkVenta")
                .OnDelete(DeleteBehavior.Cascade);

            // ── DetalleVenta → Producto ───────────────────────────────────────
            modelBuilder.Entity<DetalleVenta>()
                .HasOne(d => d.Producto)
                .WithMany()
                .HasForeignKey(d => d.FkProducto)
                .HasConstraintName("FK_DetallesVentas_Productos_FkProducto")
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
