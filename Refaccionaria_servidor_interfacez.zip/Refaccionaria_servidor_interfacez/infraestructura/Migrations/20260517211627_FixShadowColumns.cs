using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace infraestructura.Migrations
{
    /// <inheritdoc />
    public partial class FixShadowColumns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // ── DetallesVentas: eliminar columnas shadow y sus FK/índices ──────

            migrationBuilder.DropForeignKey(
                name: "FK_DetallesVentas_Productos_ProductoIdProducto",
                table: "DetallesVentas");

            migrationBuilder.DropForeignKey(
                name: "FK_DetallesVentas_Ventas_VentaIdVenta",
                table: "DetallesVentas");

            migrationBuilder.DropIndex(
                name: "IX_DetallesVentas_ProductoIdProducto",
                table: "DetallesVentas");

            migrationBuilder.DropIndex(
                name: "IX_DetallesVentas_VentaIdVenta",
                table: "DetallesVentas");

            migrationBuilder.DropColumn(
                name: "ProductoIdProducto",
                table: "DetallesVentas");

            migrationBuilder.DropColumn(
                name: "VentaIdVenta",
                table: "DetallesVentas");

            // ── Productos: eliminar columnas shadow y sus FK/índices ───────────

            migrationBuilder.DropForeignKey(
                name: "FK_Productos_Marcas_MarcaIdMarca",
                table: "Productos");

            migrationBuilder.DropForeignKey(
                name: "FK_Productos_Proveedores_ProveedorIdProveedor",
                table: "Productos");

            migrationBuilder.DropForeignKey(
                name: "FK_Productos_TiposProductos_TipoProductoIdTipoProducto",
                table: "Productos");

            migrationBuilder.DropIndex(
                name: "IX_Productos_MarcaIdMarca",
                table: "Productos");

            migrationBuilder.DropIndex(
                name: "IX_Productos_ProveedorIdProveedor",
                table: "Productos");

            migrationBuilder.DropIndex(
                name: "IX_Productos_TipoProductoIdTipoProducto",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "MarcaIdMarca",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ProveedorIdProveedor",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "TipoProductoIdTipoProducto",
                table: "Productos");

            // ── Crear índices y FK sobre las columnas reales (Fk*) ────────────

            migrationBuilder.CreateIndex(
                name: "IX_Productos_FkMarca",
                table: "Productos",
                column: "FkMarca");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_FkProveedor",
                table: "Productos",
                column: "FkProveedor");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_FkTipoProducto",
                table: "Productos",
                column: "FkTipoProducto");

            migrationBuilder.CreateIndex(
                name: "IX_DetallesVentas_FkProducto",
                table: "DetallesVentas",
                column: "FkProducto");

            migrationBuilder.CreateIndex(
                name: "IX_DetallesVentas_FkVenta",
                table: "DetallesVentas",
                column: "FkVenta");

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_Marcas_FkMarca",
                table: "Productos",
                column: "FkMarca",
                principalTable: "Marcas",
                principalColumn: "IdMarca",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_Proveedores_FkProveedor",
                table: "Productos",
                column: "FkProveedor",
                principalTable: "Proveedores",
                principalColumn: "IdProveedor",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_TiposProductos_FkTipoProducto",
                table: "Productos",
                column: "FkTipoProducto",
                principalTable: "TiposProductos",
                principalColumn: "IdTipoProducto",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_DetallesVentas_Ventas_FkVenta",
                table: "DetallesVentas",
                column: "FkVenta",
                principalTable: "Ventas",
                principalColumn: "IdVenta",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_DetallesVentas_Productos_FkProducto",
                table: "DetallesVentas",
                column: "FkProducto",
                principalTable: "Productos",
                principalColumn: "IdProducto",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Reverso: restaurar columnas shadow (para poder hacer rollback)
            migrationBuilder.DropForeignKey(name: "FK_Productos_Marcas_FkMarca",                    table: "Productos");
            migrationBuilder.DropForeignKey(name: "FK_Productos_Proveedores_FkProveedor",            table: "Productos");
            migrationBuilder.DropForeignKey(name: "FK_Productos_TiposProductos_FkTipoProducto",      table: "Productos");
            migrationBuilder.DropForeignKey(name: "FK_DetallesVentas_Ventas_FkVenta",                table: "DetallesVentas");
            migrationBuilder.DropForeignKey(name: "FK_DetallesVentas_Productos_FkProducto",          table: "DetallesVentas");
            migrationBuilder.DropIndex(name: "IX_Productos_FkMarca",             table: "Productos");
            migrationBuilder.DropIndex(name: "IX_Productos_FkProveedor",         table: "Productos");
            migrationBuilder.DropIndex(name: "IX_Productos_FkTipoProducto",      table: "Productos");
            migrationBuilder.DropIndex(name: "IX_DetallesVentas_FkProducto",     table: "DetallesVentas");
            migrationBuilder.DropIndex(name: "IX_DetallesVentas_FkVenta",        table: "DetallesVentas");

            migrationBuilder.AddColumn<int>(name: "MarcaIdMarca",                table: "Productos",     nullable: true);
            migrationBuilder.AddColumn<int>(name: "ProveedorIdProveedor",         table: "Productos",     nullable: true);
            migrationBuilder.AddColumn<int>(name: "TipoProductoIdTipoProducto",   table: "Productos",     nullable: true);
            migrationBuilder.AddColumn<int>(name: "VentaIdVenta",                 table: "DetallesVentas", nullable: true);
            migrationBuilder.AddColumn<int>(name: "ProductoIdProducto",           table: "DetallesVentas", nullable: true);
        }
    }
}
