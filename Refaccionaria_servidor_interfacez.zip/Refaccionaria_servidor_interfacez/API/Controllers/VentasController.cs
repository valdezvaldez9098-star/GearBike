using Domain;
using infraestructura;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VentasController : ControllerBase
    {
        private readonly RefaccionariaDbContext _context;

        public VentasController(RefaccionariaDbContext context)
        {
            _context = context;
        }

        public class VentaRequest
        {
            public Venta Venta { get; set; } = null!;
            public List<DetalleVenta> Detalles { get; set; } = new List<DetalleVenta>();
        }

        // GET: api/Ventas — todas las ventas ordenadas de más reciente a más antigua
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Venta>>> GetVentas()
        {
            return await _context.Ventas
                .OrderByDescending(v => v.FechaHora)
                .ToListAsync();
        }

        // GET: api/Ventas/5 — una venta con sus detalles y nombre de producto
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetVenta(int id)
        {
            var venta = await _context.Ventas.FindAsync(id);
            if (venta == null)
                return NotFound(new { Mensaje = "Venta no encontrada" });

            var detalles = await _context.DetallesVentas
                .Where(d => d.FkVenta == id)
                .Include(d => d.Producto)
                .ToListAsync();

            return Ok(new { Venta = venta, Detalles = detalles });
        }

        // POST: api/Ventas — registrar nueva venta con validación de stock
        [HttpPost]
        public async Task<ActionResult> RegistrarVenta([FromBody] VentaRequest request)
        {
            if (request.Detalles == null || request.Detalles.Count == 0)
                return BadRequest(new { Mensaje = "La venta debe tener al menos un producto" });

            // Azure SQL con retry policy no soporta BeginTransaction directamente.
            // Se usa CreateExecutionStrategy para envolver la transacción correctamente.
            var strategy = _context.Database.CreateExecutionStrategy();

            string? errorMsg = null;
            int idGenerado   = 0;

            await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await _context.Database.BeginTransactionAsync();
                try
                {
                    // Validar stock de todos los productos antes de registrar nada
                    foreach (var detalle in request.Detalles)
                    {
                        var producto = await _context.Productos.FindAsync(detalle.FkProducto);
                        if (producto == null)
                        {
                            errorMsg = $"Producto ID {detalle.FkProducto} no encontrado";
                            return;
                        }
                        if (producto.StockActual < detalle.Cantidad)
                        {
                            errorMsg = $"Stock insuficiente para '{producto.Nombre}'. Disponible: {producto.StockActual}";
                            return;
                        }
                    }

                    // Guardar cabecera
                    request.Venta.FechaHora = DateTime.Now;
                    _context.Ventas.Add(request.Venta);
                    await _context.SaveChangesAsync();

                    // Guardar detalles y descontar stock
                    foreach (var detalle in request.Detalles)
                    {
                        detalle.FkVenta = request.Venta.IdVenta;
                        _context.DetallesVentas.Add(detalle);

                        var producto = await _context.Productos.FindAsync(detalle.FkProducto);
                        if (producto != null)
                            producto.StockActual -= detalle.Cantidad;
                    }

                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();
                    idGenerado = request.Venta.IdVenta;
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            });

            if (errorMsg != null)
                return BadRequest(new { Mensaje = errorMsg });

            return Ok(new { Mensaje = "Venta registrada con éxito", IdGenerado = idGenerado });
        }
    }
}
