using Domain;
using infraestructura;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private readonly RefaccionariaDbContext _context;

        public ProductosController(RefaccionariaDbContext context)
        {
            _context = context;
        }

        // GET: api/Productos
        // Devuelve todos los productos incluyendo su Marca asociada
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Producto>>> GetProductos()
        {
            return await _context.Productos
                .Include(p => p.Marca)
                .ToListAsync();
        }

        // GET: api/Productos/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Producto>> GetProducto(int id)
        {
            var producto = await _context.Productos
                .Include(p => p.Marca)
                .FirstOrDefaultAsync(p => p.IdProducto == id);

            if (producto == null)
                return NotFound(new { Mensaje = "Producto no encontrado" });

            return producto;
        }

        // POST: api/Productos  — crear nuevo producto
        [HttpPost]
        public async Task<ActionResult<Producto>> PostProducto(Producto producto)
        {
            // Validaciones básicas
            if (string.IsNullOrWhiteSpace(producto.Nombre))
                return BadRequest(new { Mensaje = "El nombre del producto es obligatorio" });

            if (producto.PrecioVenta <= 0)
                return BadRequest(new { Mensaje = "El precio de venta debe ser mayor a 0" });

            if (producto.StockActual < 0)
                return BadRequest(new { Mensaje = "El stock no puede ser negativo" });

            _context.Productos.Add(producto);
            await _context.SaveChangesAsync();

            return Ok(new { Mensaje = "Producto creado con éxito", Producto = producto });
        }

        // PUT: api/Productos/5  — editar producto existente
        [HttpPut("{id}")]
        public async Task<ActionResult> PutProducto(int id, Producto producto)
        {
            if (id != producto.IdProducto)
                return BadRequest(new { Mensaje = "El ID del producto no coincide" });

            var existe = await _context.Productos.AnyAsync(p => p.IdProducto == id);
            if (!existe)
                return NotFound(new { Mensaje = "Producto no encontrado" });

            if (string.IsNullOrWhiteSpace(producto.Nombre))
                return BadRequest(new { Mensaje = "El nombre del producto es obligatorio" });

            if (producto.PrecioVenta <= 0)
                return BadRequest(new { Mensaje = "El precio de venta debe ser mayor a 0" });

            _context.Entry(producto).State = EntityState.Modified;

            // No sobreescribir propiedades de navegación
            _context.Entry(producto).Reference(p => p.Marca).IsModified = false;
            _context.Entry(producto).Reference(p => p.Proveedor).IsModified = false;
            _context.Entry(producto).Reference(p => p.TipoProducto).IsModified = false;

            await _context.SaveChangesAsync();

            return Ok(new { Mensaje = "Producto actualizado con éxito" });
        }
    }
}
